#include "objects/lacewing.h"

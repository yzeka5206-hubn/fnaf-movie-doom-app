#include "objects.h"
#include "common.h"
#include "fonts.h"
#include "font.h"
#include "lists.h"

static Image* images_warning_0_0_0[1];
static Direction direction_warning_0_0_0 = {0, 50, 50, 0, 1, images_warning_0_0_0, 1};
static Animation anim_warning_0_0 = {&direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, NULL, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0, &direction_warning_0_0_0};
static Animation * anim_array_warning_0[1] = {&anim_warning_0_0};
static Animations anim_warning_0 = {1, &anim_array_warning_0[0]};
static bool anim_warning_0_initialized;
class Warning_0 : public Active
{
public:
    Warning_0(int x, int y) : Active(x, y, Warning_0_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("Warning", 7);
#endif
        this->animations = &anim_warning_0;
        if (!anim_warning_0_initialized) {
            anim_warning_0_initialized = true;
            images_warning_0_0_0[0] = get_internal_image(51);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 1);
    }
};
FrameObject * create_warning_0(int x, int y)
{
    return new (Active::pool.create()) Warning_0(x, y);
}
static Image* images_fade_1_0_0[1];
static Direction direction_fade_1_0_0 = {0, 50, 50, 0, 1, images_fade_1_0_0, 1};
static Animation anim_fade_1_0 = {&direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, NULL, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0, &direction_fade_1_0_0};
static Animation * anim_array_fade_1[1] = {&anim_fade_1_0};
static Animations anim_fade_1 = {1, &anim_array_fade_1[0]};
static bool anim_fade_1_initialized;
class Fade_1 : public Active
{
public:
    Fade_1(int x, int y) : Active(x, y, Fade_1_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("Fade", 4);
#endif
        this->animations = &anim_fade_1;
        if (!anim_fade_1_initialized) {
            anim_fade_1_initialized = true;
            images_fade_1_0_0[0] = get_internal_image(54);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_fade_1(int x, int y)
{
    return new (Active::pool.create()) Fade_1(x, y);
}
static Image* images_easteregg_3_0_0[1];
static Direction direction_easteregg_3_0_0 = {0, 50, 50, 0, 1, images_easteregg_3_0_0, 1};
static Animation anim_easteregg_3_0 = {&direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, NULL, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0, &direction_easteregg_3_0_0};
static Animation * anim_array_easteregg_3[1] = {&anim_easteregg_3_0};
static Animations anim_easteregg_3 = {1, &anim_array_easteregg_3[0]};
static bool anim_easteregg_3_initialized;
class EasterEgg_3 : public Active
{
public:
    EasterEgg_3(int x, int y) : Active(x, y, EasterEgg_3_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("EasterEgg", 9);
#endif
        set_visible(false);
        this->animations = &anim_easteregg_3;
        if (!anim_easteregg_3_initialized) {
            anim_easteregg_3_initialized = true;
            images_easteregg_3_0_0[0] = get_internal_image(74);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_easteregg_3(int x, int y)
{
    return new (Active::pool.create()) EasterEgg_3(x, y);
}
static Image* images_fundowarning_4_0_0[1];
static Direction direction_fundowarning_4_0_0 = {0, 50, 50, 0, 1, images_fundowarning_4_0_0, 1};
static Animation anim_fundowarning_4_0 = {&direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, NULL, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0, &direction_fundowarning_4_0_0};
static Animation * anim_array_fundowarning_4[1] = {&anim_fundowarning_4_0};
static Animations anim_fundowarning_4 = {1, &anim_array_fundowarning_4[0]};
static bool anim_fundowarning_4_initialized;
class FundoWarning_4 : public Active
{
public:
    FundoWarning_4(int x, int y) : Active(x, y, FundoWarning_4_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("FundoWarning", 12);
#endif
        this->animations = &anim_fundowarning_4;
        if (!anim_fundowarning_4_initialized) {
            anim_fundowarning_4_initialized = true;
            images_fundowarning_4_0_0[0] = get_internal_image(70);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        blend_color = Color(255, 255, 255, 105);
        create_alterables();
    }
};
FrameObject * create_fundowarning_4(int x, int y)
{
    return new (Active::pool.create()) FundoWarning_4(x, y);
}
static Image* images_vinheta_5_0_0[1];
static Direction direction_vinheta_5_0_0 = {0, 50, 50, 0, 1, images_vinheta_5_0_0, 1};
static Animation anim_vinheta_5_0 = {&direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, NULL, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0, &direction_vinheta_5_0_0};
static Animation * anim_array_vinheta_5[1] = {&anim_vinheta_5_0};
static Animations anim_vinheta_5 = {1, &anim_array_vinheta_5[0]};
static bool anim_vinheta_5_initialized;
class Vinheta_5 : public Active
{
public:
    Vinheta_5(int x, int y) : Active(x, y, Vinheta_5_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("Vinheta", 7);
#endif
        this->animations = &anim_vinheta_5;
        if (!anim_vinheta_5_initialized) {
            anim_vinheta_5_initialized = true;
            images_vinheta_5_0_0[0] = get_internal_image(29);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_vinheta_5(int x, int y)
{
    return new (Active::pool.create()) Vinheta_5(x, y);
}
static Image* images_easteregg_6_0_0[1];
static Direction direction_easteregg_6_0_0 = {0, 50, 50, 0, 1, images_easteregg_6_0_0, 1};
static Animation anim_easteregg_6_0 = {&direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, NULL, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0, &direction_easteregg_6_0_0};
static Animation * anim_array_easteregg_6[1] = {&anim_easteregg_6_0};
static Animations anim_easteregg_6 = {1, &anim_array_easteregg_6[0]};
static bool anim_easteregg_6_initialized;
class EASTEREGG_6 : public Active
{
public:
    EASTEREGG_6(int x, int y) : Active(x, y, EASTEREGG_6_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("EASTER EGG", 10);
#endif
        this->animations = &anim_easteregg_6;
        if (!anim_easteregg_6_initialized) {
            anim_easteregg_6_initialized = true;
            images_easteregg_6_0_0[0] = get_internal_image(0);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_easteregg_6(int x, int y)
{
    return new (Active::pool.create()) EASTEREGG_6(x, y);
}
static Image* images_hudbackground_7_0_0[4];
static Direction direction_hudbackground_7_0_0 = {0, 0, 0, 0, 1, images_hudbackground_7_0_0, 4};
static Animation anim_hudbackground_7_0 = {&direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, NULL, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0, &direction_hudbackground_7_0_0};
static Animation * anim_array_hudbackground_7[1] = {&anim_hudbackground_7_0};
static Animations anim_hudbackground_7 = {1, &anim_array_hudbackground_7[0]};
static bool anim_hudbackground_7_initialized;
class HUDBackground_7 : public Active
{
public:
    HUDBackground_7(int x, int y) : Active(x, y, HUDBackground_7_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - Background", 16);
#endif
        this->animations = &anim_hudbackground_7;
        if (!anim_hudbackground_7_initialized) {
            anim_hudbackground_7_initialized = true;
            images_hudbackground_7_0_0[0] = get_internal_image(80);
            images_hudbackground_7_0_0[1] = get_internal_image(81);
            images_hudbackground_7_0_0[2] = get_internal_image(82);
            images_hudbackground_7_0_0[3] = get_internal_image(83);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_hudbackground_7(int x, int y)
{
    return new (Active::pool.create()) HUDBackground_7(x, y);
}
static Image* images_menulogo_8_0_0[1];
static Direction direction_menulogo_8_0_0 = {0, 50, 50, 0, 1, images_menulogo_8_0_0, 1};
static Animation anim_menulogo_8_0 = {&direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, NULL, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0, &direction_menulogo_8_0_0};
static Animation * anim_array_menulogo_8[1] = {&anim_menulogo_8_0};
static Animations anim_menulogo_8 = {1, &anim_array_menulogo_8[0]};
static bool anim_menulogo_8_initialized;
class MENULogo_8 : public Active
{
public:
    MENULogo_8(int x, int y) : Active(x, y, MENULogo_8_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("MENU - Logo", 11);
#endif
        this->animations = &anim_menulogo_8;
        if (!anim_menulogo_8_initialized) {
            anim_menulogo_8_initialized = true;
            images_menulogo_8_0_0[0] = get_internal_image(4);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_menulogo_8(int x, int y)
{
    return new (Active::pool.create()) MENULogo_8(x, y);
}
static Image* images_menumultiplayer_9_0_0[1];
static Direction direction_menumultiplayer_9_0_0 = {0, 50, 50, 0, 1, images_menumultiplayer_9_0_0, 1};
static Animation anim_menumultiplayer_9_0 = {&direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, NULL, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0, &direction_menumultiplayer_9_0_0};
static Animation * anim_array_menumultiplayer_9[1] = {&anim_menumultiplayer_9_0};
static Animations anim_menumultiplayer_9 = {1, &anim_array_menumultiplayer_9[0]};
static bool anim_menumultiplayer_9_initialized;
class MENUMultiplayer_9 : public Active
{
public:
    MENUMultiplayer_9(int x, int y) : Active(x, y, MENUMultiplayer_9_type)
    {
        // qualifiers: 0, 90
#ifndef NDEBUG
        name = std::string("MENU - Multiplayer", 18);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_menumultiplayer_9;
        if (!anim_menumultiplayer_9_initialized) {
            anim_menumultiplayer_9_initialized = true;
            images_menumultiplayer_9_0_0[0] = get_internal_image(5);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 822);
    }
};
FrameObject * create_menumultiplayer_9(int x, int y)
{
    return new (Active::pool.create()) MENUMultiplayer_9(x, y);
}
static Image* images_menusingleplayer_10_0_0[1];
static Direction direction_menusingleplayer_10_0_0 = {0, 50, 50, 0, 1, images_menusingleplayer_10_0_0, 1};
static Animation anim_menusingleplayer_10_0 = {&direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, NULL, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0, &direction_menusingleplayer_10_0_0};
static Animation * anim_array_menusingleplayer_10[1] = {&anim_menusingleplayer_10_0};
static Animations anim_menusingleplayer_10 = {1, &anim_array_menusingleplayer_10[0]};
static bool anim_menusingleplayer_10_initialized;
class MENUSingleplayer_10 : public Active
{
public:
    MENUSingleplayer_10(int x, int y) : Active(x, y, MENUSingleplayer_10_type)
    {
        // qualifiers: 0, 90
#ifndef NDEBUG
        name = std::string("MENU - Singleplayer", 19);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_menusingleplayer_10;
        if (!anim_menusingleplayer_10_initialized) {
            anim_menusingleplayer_10_initialized = true;
            images_menusingleplayer_10_0_0[0] = get_internal_image(3);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 364);
    }
};
FrameObject * create_menusingleplayer_10(int x, int y)
{
    return new (Active::pool.create()) MENUSingleplayer_10(x, y);
}
static Image* images_menuoptions_11_0_0[1];
static Direction direction_menuoptions_11_0_0 = {0, 50, 50, 0, 1, images_menuoptions_11_0_0, 1};
static Animation anim_menuoptions_11_0 = {&direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, NULL, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0, &direction_menuoptions_11_0_0};
static Animation * anim_array_menuoptions_11[1] = {&anim_menuoptions_11_0};
static Animations anim_menuoptions_11 = {1, &anim_array_menuoptions_11[0]};
static bool anim_menuoptions_11_initialized;
class MENUOptions_11 : public Active
{
public:
    MENUOptions_11(int x, int y) : Active(x, y, MENUOptions_11_type)
    {
        // qualifiers: 0, 90
#ifndef NDEBUG
        name = std::string("MENU - Options", 14);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_menuoptions_11;
        if (!anim_menuoptions_11_initialized) {
            anim_menuoptions_11_initialized = true;
            images_menuoptions_11_0_0[0] = get_internal_image(6);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 262);
    }
};
FrameObject * create_menuoptions_11(int x, int y)
{
    return new (Active::pool.create()) MENUOptions_11(x, y);
}
static Image* images_hudcrditos_12_0_0[1];
static Direction direction_hudcrditos_12_0_0 = {0, 50, 50, 0, 1, images_hudcrditos_12_0_0, 1};
static Animation anim_hudcrditos_12_0 = {&direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, NULL, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0, &direction_hudcrditos_12_0_0};
static Animation * anim_array_hudcrditos_12[1] = {&anim_hudcrditos_12_0};
static Animations anim_hudcrditos_12 = {1, &anim_array_hudcrditos_12[0]};
static bool anim_hudcrditos_12_initialized;
class HUDCrDitos_12 : public Active
{
public:
    HUDCrDitos_12(int x, int y) : Active(x, y, HUDCrDitos_12_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - Cr\303\251ditos", 15);
#endif
        this->animations = &anim_hudcrditos_12;
        if (!anim_hudcrditos_12_initialized) {
            anim_hudcrditos_12_initialized = true;
            images_hudcrditos_12_0_0[0] = get_internal_image(79);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_hudcrditos_12(int x, int y)
{
    return new (Active::pool.create()) HUDCrDitos_12(x, y);
}
static Image* images_hudindicadorsingleplayer_13_0_0[1];
static Direction direction_hudindicadorsingleplayer_13_0_0 = {0, 50, 50, 0, 1, images_hudindicadorsingleplayer_13_0_0, 1};
static Animation anim_hudindicadorsingleplayer_13_0 = {&direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, NULL, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0, &direction_hudindicadorsingleplayer_13_0_0};
static Animation * anim_array_hudindicadorsingleplayer_13[1] = {&anim_hudindicadorsingleplayer_13_0};
static Animations anim_hudindicadorsingleplayer_13 = {1, &anim_array_hudindicadorsingleplayer_13[0]};
static bool anim_hudindicadorsingleplayer_13_initialized;
class HUDIndicadorSingleplayer_13 : public Active
{
public:
    HUDIndicadorSingleplayer_13(int x, int y) : Active(x, y, HUDIndicadorSingleplayer_13_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - IndicadorSingleplayer", 27);
#endif
        this->animations = &anim_hudindicadorsingleplayer_13;
        if (!anim_hudindicadorsingleplayer_13_initialized) {
            anim_hudindicadorsingleplayer_13_initialized = true;
            images_hudindicadorsingleplayer_13_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_hudindicadorsingleplayer_13(int x, int y)
{
    return new (Active::pool.create()) HUDIndicadorSingleplayer_13(x, y);
}
static Image* images_hudindicadormultiplayer_14_0_0[1];
static Direction direction_hudindicadormultiplayer_14_0_0 = {0, 50, 50, 0, 1, images_hudindicadormultiplayer_14_0_0, 1};
static Animation anim_hudindicadormultiplayer_14_0 = {&direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, NULL, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0, &direction_hudindicadormultiplayer_14_0_0};
static Animation * anim_array_hudindicadormultiplayer_14[1] = {&anim_hudindicadormultiplayer_14_0};
static Animations anim_hudindicadormultiplayer_14 = {1, &anim_array_hudindicadormultiplayer_14[0]};
static bool anim_hudindicadormultiplayer_14_initialized;
class HUDIndicadorMultiplayer_14 : public Active
{
public:
    HUDIndicadorMultiplayer_14(int x, int y) : Active(x, y, HUDIndicadorMultiplayer_14_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - IndicadorMultiplayer", 26);
#endif
        this->animations = &anim_hudindicadormultiplayer_14;
        if (!anim_hudindicadormultiplayer_14_initialized) {
            anim_hudindicadormultiplayer_14_initialized = true;
            images_hudindicadormultiplayer_14_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_hudindicadormultiplayer_14(int x, int y)
{
    return new (Active::pool.create()) HUDIndicadorMultiplayer_14(x, y);
}
static Image* images_hudindicadoroptions_15_0_0[1];
static Direction direction_hudindicadoroptions_15_0_0 = {0, 50, 50, 0, 1, images_hudindicadoroptions_15_0_0, 1};
static Animation anim_hudindicadoroptions_15_0 = {&direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, NULL, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0, &direction_hudindicadoroptions_15_0_0};
static Animation * anim_array_hudindicadoroptions_15[1] = {&anim_hudindicadoroptions_15_0};
static Animations anim_hudindicadoroptions_15 = {1, &anim_array_hudindicadoroptions_15[0]};
static bool anim_hudindicadoroptions_15_initialized;
class HUDIndicadorOptions_15 : public Active
{
public:
    HUDIndicadorOptions_15(int x, int y) : Active(x, y, HUDIndicadorOptions_15_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - IndicadorOptions", 22);
#endif
        this->animations = &anim_hudindicadoroptions_15;
        if (!anim_hudindicadoroptions_15_initialized) {
            anim_hudindicadoroptions_15_initialized = true;
            images_hudindicadoroptions_15_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_hudindicadoroptions_15(int x, int y)
{
    return new (Active::pool.create()) HUDIndicadorOptions_15(x, y);
}
static Image* images_bancodedadoslauncher_17_0_0[1];
static Direction direction_bancodedadoslauncher_17_0_0 = {0, 50, 50, 0, 1, images_bancodedadoslauncher_17_0_0, 1};
static Animation anim_bancodedadoslauncher_17_0 = {&direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, NULL, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0, &direction_bancodedadoslauncher_17_0_0};
static Animation * anim_array_bancodedadoslauncher_17[1] = {&anim_bancodedadoslauncher_17_0};
static Animations anim_bancodedadoslauncher_17 = {1, &anim_array_bancodedadoslauncher_17[0]};
static bool anim_bancodedadoslauncher_17_initialized;
class BANCODEDADOSLauncher_17 : public Active
{
public:
    BANCODEDADOSLauncher_17(int x, int y) : Active(x, y, BANCODEDADOSLauncher_17_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("BANCO DE DADOS - Launcher", 25);
#endif
        this->animations = &anim_bancodedadoslauncher_17;
        if (!anim_bancodedadoslauncher_17_initialized) {
            anim_bancodedadoslauncher_17_initialized = true;
            images_bancodedadoslauncher_17_0_0[0] = get_internal_image(0);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(7, 2);
        alterables->strings.set(2, str_file_movie_shaders_0);
        alterables->strings.set(3, str_file_movie_1);
        alterables->strings.set(4, str_file_movie_postprocess_2);
    }
};
FrameObject * create_bancodedadoslauncher_17(int x, int y)
{
    return new (Active::pool.create()) BANCODEDADOSLauncher_17(x, y);
}
static Image* images_bancodedadosinteraomenu_18_0_0[1];
static Direction direction_bancodedadosinteraomenu_18_0_0 = {0, 50, 50, 0, 1, images_bancodedadosinteraomenu_18_0_0, 1};
static Animation anim_bancodedadosinteraomenu_18_0 = {&direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, NULL, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0, &direction_bancodedadosinteraomenu_18_0_0};
static Animation * anim_array_bancodedadosinteraomenu_18[1] = {&anim_bancodedadosinteraomenu_18_0};
static Animations anim_bancodedadosinteraomenu_18 = {1, &anim_array_bancodedadosinteraomenu_18[0]};
static bool anim_bancodedadosinteraomenu_18_initialized;
class BANCODEDADOSInteraOMenu_18 : public Active
{
public:
    BANCODEDADOSInteraOMenu_18(int x, int y) : Active(x, y, BANCODEDADOSInteraOMenu_18_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("BANCO DE DADOS - Intera\303\247\303\243o Menu", 33);
#endif
        this->animations = &anim_bancodedadosinteraomenu_18;
        if (!anim_bancodedadosinteraomenu_18_initialized) {
            anim_bancodedadosinteraomenu_18_initialized = true;
            images_bancodedadosinteraomenu_18_0_0[0] = get_internal_image(0);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->flags.flags = 32U;
    }
};
FrameObject * create_bancodedadosinteraomenu_18(int x, int y)
{
    return new (Active::pool.create()) BANCODEDADOSInteraOMenu_18(x, y);
}
static Image* images_opesdificuldade_19_0_0[1];
static Direction direction_opesdificuldade_19_0_0 = {0, 50, 50, 0, 1, images_opesdificuldade_19_0_0, 1};
static Animation anim_opesdificuldade_19_0 = {&direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, NULL, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0, &direction_opesdificuldade_19_0_0};
static Animation * anim_array_opesdificuldade_19[1] = {&anim_opesdificuldade_19_0};
static Animations anim_opesdificuldade_19 = {1, &anim_array_opesdificuldade_19[0]};
static bool anim_opesdificuldade_19_initialized;
class OPESDificuldade_19 : public Active
{
public:
    OPESDificuldade_19(int x, int y) : Active(x, y, OPESDificuldade_19_type)
    {
        // qualifiers: 19, 95
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Dificuldade", 22);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_opesdificuldade_19;
        if (!anim_opesdificuldade_19_initialized) {
            anim_opesdificuldade_19_initialized = true;
            images_opesdificuldade_19_0_0[0] = get_internal_image(8);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 128);
    }
};
FrameObject * create_opesdificuldade_19(int x, int y)
{
    return new (Active::pool.create()) OPESDificuldade_19(x, y);
}
static Image* images_opesshaders_20_0_0[1];
static Direction direction_opesshaders_20_0_0 = {0, 50, 50, 0, 1, images_opesshaders_20_0_0, 1};
static Animation anim_opesshaders_20_0 = {&direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, NULL, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0, &direction_opesshaders_20_0_0};
static Animation * anim_array_opesshaders_20[1] = {&anim_opesshaders_20_0};
static Animations anim_opesshaders_20 = {1, &anim_array_opesshaders_20[0]};
static bool anim_opesshaders_20_initialized;
class OPESShaders_20 : public Active
{
public:
    OPESShaders_20(int x, int y) : Active(x, y, OPESShaders_20_type)
    {
        // qualifiers: 19, 95
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Shaders", 18);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_opesshaders_20;
        if (!anim_opesshaders_20_initialized) {
            anim_opesshaders_20_initialized = true;
            images_opesshaders_20_0_0[0] = get_internal_image(9);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 128);
    }
};
FrameObject * create_opesshaders_20(int x, int y)
{
    return new (Active::pool.create()) OPESShaders_20(x, y);
}
static Image* images_opesstreamermodehud_21_0_0[1];
static Direction direction_opesstreamermodehud_21_0_0 = {0, 50, 50, 0, 1, images_opesstreamermodehud_21_0_0, 1};
static Animation anim_opesstreamermodehud_21_0 = {&direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, NULL, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0, &direction_opesstreamermodehud_21_0_0};
static Animation * anim_array_opesstreamermodehud_21[1] = {&anim_opesstreamermodehud_21_0};
static Animations anim_opesstreamermodehud_21 = {1, &anim_array_opesstreamermodehud_21[0]};
static bool anim_opesstreamermodehud_21_initialized;
class OPESStreamerModeHUD_21 : public Active
{
public:
    OPESStreamerModeHUD_21(int x, int y) : Active(x, y, OPESStreamerModeHUD_21_type)
    {
        // qualifiers: 19, 95
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Streamer Mode HUD", 28);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_opesstreamermodehud_21;
        if (!anim_opesstreamermodehud_21_initialized) {
            anim_opesstreamermodehud_21_initialized = true;
            images_opesstreamermodehud_21_0_0[0] = get_internal_image(14);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 128);
    }
};
FrameObject * create_opesstreamermodehud_21(int x, int y)
{
    return new (Active::pool.create()) OPESStreamerModeHUD_21(x, y);
}
static Image* images_opesvoltar_22_0_0[1];
static Direction direction_opesvoltar_22_0_0 = {0, 50, 50, 0, 1, images_opesvoltar_22_0_0, 1};
static Animation anim_opesvoltar_22_0 = {&direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, NULL, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0, &direction_opesvoltar_22_0_0};
static Animation * anim_array_opesvoltar_22[1] = {&anim_opesvoltar_22_0};
static Animations anim_opesvoltar_22 = {1, &anim_array_opesvoltar_22[0]};
static bool anim_opesvoltar_22_initialized;
class OPESVoltar_22 : public Active
{
public:
    OPESVoltar_22(int x, int y) : Active(x, y, OPESVoltar_22_type)
    {
        // qualifiers: 19, 42, 95
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Voltar", 17);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_opesvoltar_22;
        if (!anim_opesvoltar_22_initialized) {
            anim_opesvoltar_22_initialized = true;
            images_opesvoltar_22_0_0[0] = get_internal_image(12);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(1, 127);
    }
};
FrameObject * create_opesvoltar_22(int x, int y)
{
    return new (Active::pool.create()) OPESVoltar_22(x, y);
}
static Image* images_opesbotodificuldade_23_0_0[3];
static Direction direction_opesbotodificuldade_23_0_0 = {0, 0, 0, 0, -1, images_opesbotodificuldade_23_0_0, 3};
static Animation anim_opesbotodificuldade_23_0 = {&direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, NULL, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0, &direction_opesbotodificuldade_23_0_0};
static Animation * anim_array_opesbotodificuldade_23[1] = {&anim_opesbotodificuldade_23_0};
static Animations anim_opesbotodificuldade_23 = {1, &anim_array_opesbotodificuldade_23[0]};
static bool anim_opesbotodificuldade_23_initialized;
class OPESBotODificuldade_23 : public Active
{
public:
    OPESBotODificuldade_23(int x, int y) : Active(x, y, OPESBotODificuldade_23_type)
    {
        // qualifiers: 19
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Bot\303\243o Dificuldade", 29);
#endif
        this->animations = &anim_opesbotodificuldade_23;
        if (!anim_opesbotodificuldade_23_initialized) {
            anim_opesbotodificuldade_23_initialized = true;
            images_opesbotodificuldade_23_0_0[0] = get_internal_image(15);
            images_opesbotodificuldade_23_0_0[1] = get_internal_image(13);
            images_opesbotodificuldade_23_0_0[2] = get_internal_image(7);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 520);
    }
};
FrameObject * create_opesbotodificuldade_23(int x, int y)
{
    return new (Active::pool.create()) OPESBotODificuldade_23(x, y);
}
static Image* images_opesbotostreamermode_24_0_0[2];
static Direction direction_opesbotostreamermode_24_0_0 = {0, 0, 0, 0, -1, images_opesbotostreamermode_24_0_0, 2};
static Animation anim_opesbotostreamermode_24_0 = {&direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, NULL, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0, &direction_opesbotostreamermode_24_0_0};
static Animation * anim_array_opesbotostreamermode_24[1] = {&anim_opesbotostreamermode_24_0};
static Animations anim_opesbotostreamermode_24 = {1, &anim_array_opesbotostreamermode_24[0]};
static bool anim_opesbotostreamermode_24_initialized;
class OPESBotOStreamerMode_24 : public Active
{
public:
    OPESBotOStreamerMode_24(int x, int y) : Active(x, y, OPESBotOStreamerMode_24_type)
    {
        // qualifiers: 19
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Bot\303\243o Streamer Mode", 31);
#endif
        this->animations = &anim_opesbotostreamermode_24;
        if (!anim_opesbotostreamermode_24_initialized) {
            anim_opesbotostreamermode_24_initialized = true;
            images_opesbotostreamermode_24_0_0[0] = get_internal_image(17);
            images_opesbotostreamermode_24_0_0[1] = get_internal_image(16);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 712);
    }
};
FrameObject * create_opesbotostreamermode_24(int x, int y)
{
    return new (Active::pool.create()) OPESBotOStreamerMode_24(x, y);
}
static Image* images_opesbotoshaders_25_0_0[2];
static Direction direction_opesbotoshaders_25_0_0 = {0, 0, 0, 0, -1, images_opesbotoshaders_25_0_0, 2};
static Animation anim_opesbotoshaders_25_0 = {&direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, NULL, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0, &direction_opesbotoshaders_25_0_0};
static Animation * anim_array_opesbotoshaders_25[1] = {&anim_opesbotoshaders_25_0};
static Animations anim_opesbotoshaders_25 = {1, &anim_array_opesbotoshaders_25[0]};
static bool anim_opesbotoshaders_25_initialized;
class OPESBotOShaders_25 : public Active
{
public:
    OPESBotOShaders_25(int x, int y) : Active(x, y, OPESBotOShaders_25_type)
    {
        // qualifiers: 19
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Bot\303\243o Shaders", 25);
#endif
        this->animations = &anim_opesbotoshaders_25;
        if (!anim_opesbotoshaders_25_initialized) {
            anim_opesbotoshaders_25_initialized = true;
            images_opesbotoshaders_25_0_0[0] = get_internal_image(17);
            images_opesbotoshaders_25_0_0[1] = get_internal_image(16);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(1, 1);
        alterables->values.set(2, 680);
    }
};
FrameObject * create_opesbotoshaders_25(int x, int y)
{
    return new (Active::pool.create()) OPESBotOShaders_25(x, y);
}
static Image* images_opesindicadorvoltar_26_0_0[1];
static Direction direction_opesindicadorvoltar_26_0_0 = {0, 50, 50, 0, 1, images_opesindicadorvoltar_26_0_0, 1};
static Animation anim_opesindicadorvoltar_26_0 = {&direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, NULL, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0, &direction_opesindicadorvoltar_26_0_0};
static Animation * anim_array_opesindicadorvoltar_26[1] = {&anim_opesindicadorvoltar_26_0};
static Animations anim_opesindicadorvoltar_26 = {1, &anim_array_opesindicadorvoltar_26[0]};
static bool anim_opesindicadorvoltar_26_initialized;
class OPESIndicadorVoltar_26 : public Active
{
public:
    OPESIndicadorVoltar_26(int x, int y) : Active(x, y, OPESIndicadorVoltar_26_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - IndicadorVoltar", 26);
#endif
        this->animations = &anim_opesindicadorvoltar_26;
        if (!anim_opesindicadorvoltar_26_initialized) {
            anim_opesindicadorvoltar_26_initialized = true;
            images_opesindicadorvoltar_26_0_0[0] = get_internal_image(11);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 37);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_opesindicadorvoltar_26(int x, int y)
{
    return new (Active::pool.create()) OPESIndicadorVoltar_26(x, y);
}
static Image* images_opesindicadorstreamermode_27_0_0[1];
static Direction direction_opesindicadorstreamermode_27_0_0 = {0, 50, 50, 0, 1, images_opesindicadorstreamermode_27_0_0, 1};
static Animation anim_opesindicadorstreamermode_27_0 = {&direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, NULL, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0, &direction_opesindicadorstreamermode_27_0_0};
static Animation * anim_array_opesindicadorstreamermode_27[1] = {&anim_opesindicadorstreamermode_27_0};
static Animations anim_opesindicadorstreamermode_27 = {1, &anim_array_opesindicadorstreamermode_27[0]};
static bool anim_opesindicadorstreamermode_27_initialized;
class OPESIndicadorStreamerMode_27 : public Active
{
public:
    OPESIndicadorStreamerMode_27(int x, int y) : Active(x, y, OPESIndicadorStreamerMode_27_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - IndicadorStreamerMode", 32);
#endif
        this->animations = &anim_opesindicadorstreamermode_27;
        if (!anim_opesindicadorstreamermode_27_initialized) {
            anim_opesindicadorstreamermode_27_initialized = true;
            images_opesindicadorstreamermode_27_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_opesindicadorstreamermode_27(int x, int y)
{
    return new (Active::pool.create()) OPESIndicadorStreamerMode_27(x, y);
}
static Image* images_opesindicadordificuldade_28_0_0[1];
static Direction direction_opesindicadordificuldade_28_0_0 = {0, 50, 50, 0, 1, images_opesindicadordificuldade_28_0_0, 1};
static Animation anim_opesindicadordificuldade_28_0 = {&direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, NULL, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0, &direction_opesindicadordificuldade_28_0_0};
static Animation * anim_array_opesindicadordificuldade_28[1] = {&anim_opesindicadordificuldade_28_0};
static Animations anim_opesindicadordificuldade_28 = {1, &anim_array_opesindicadordificuldade_28[0]};
static bool anim_opesindicadordificuldade_28_initialized;
class OPESIndicadorDificuldade_28 : public Active
{
public:
    OPESIndicadorDificuldade_28(int x, int y) : Active(x, y, OPESIndicadorDificuldade_28_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - IndicadorDificuldade", 31);
#endif
        this->animations = &anim_opesindicadordificuldade_28;
        if (!anim_opesindicadordificuldade_28_initialized) {
            anim_opesindicadordificuldade_28_initialized = true;
            images_opesindicadordificuldade_28_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_opesindicadordificuldade_28(int x, int y)
{
    return new (Active::pool.create()) OPESIndicadorDificuldade_28(x, y);
}
static Image* images_opesindicadorshaders_29_0_0[1];
static Direction direction_opesindicadorshaders_29_0_0 = {0, 50, 50, 0, 1, images_opesindicadorshaders_29_0_0, 1};
static Animation anim_opesindicadorshaders_29_0 = {&direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, NULL, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0, &direction_opesindicadorshaders_29_0_0};
static Animation * anim_array_opesindicadorshaders_29[1] = {&anim_opesindicadorshaders_29_0};
static Animations anim_opesindicadorshaders_29 = {1, &anim_array_opesindicadorshaders_29[0]};
static bool anim_opesindicadorshaders_29_initialized;
class OPESIndicadorShaders_29 : public Active
{
public:
    OPESIndicadorShaders_29(int x, int y) : Active(x, y, OPESIndicadorShaders_29_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - IndicadorShaders", 27);
#endif
        this->animations = &anim_opesindicadorshaders_29;
        if (!anim_opesindicadorshaders_29_initialized) {
            anim_opesindicadorshaders_29_initialized = true;
            images_opesindicadorshaders_29_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_opesindicadorshaders_29(int x, int y)
{
    return new (Active::pool.create()) OPESIndicadorShaders_29(x, y);
}
static Image* images_hudchiado_30_0_0[8];
static Direction direction_hudchiado_30_0_0 = {0, 50, 50, 0, -1, images_hudchiado_30_0_0, 8};
static Animation anim_hudchiado_30_0 = {&direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, NULL, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0, &direction_hudchiado_30_0_0};
static Animation * anim_array_hudchiado_30[1] = {&anim_hudchiado_30_0};
static Animations anim_hudchiado_30 = {1, &anim_array_hudchiado_30[0]};
static bool anim_hudchiado_30_initialized;
class HUDChiado_30 : public Active
{
public:
    HUDChiado_30(int x, int y) : Active(x, y, HUDChiado_30_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - Chiado", 12);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_hudchiado_30;
        if (!anim_hudchiado_30_initialized) {
            anim_hudchiado_30_initialized = true;
            images_hudchiado_30_0_0[0] = get_internal_image(21);
            images_hudchiado_30_0_0[1] = get_internal_image(22);
            images_hudchiado_30_0_0[2] = get_internal_image(23);
            images_hudchiado_30_0_0[3] = get_internal_image(24);
            images_hudchiado_30_0_0[4] = get_internal_image(25);
            images_hudchiado_30_0_0[5] = get_internal_image(26);
            images_hudchiado_30_0_0[6] = get_internal_image(27);
            images_hudchiado_30_0_0[7] = get_internal_image(28);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        blend_color = Color(255, 255, 255, 55);
        set_shader(Render::ADDITIVE);
        create_alterables();
    }
};
FrameObject * create_hudchiado_30(int x, int y)
{
    return new (Active::pool.create()) HUDChiado_30(x, y);
}
static Image* images_hudvinheta_31_0_0[1];
static Direction direction_hudvinheta_31_0_0 = {0, 50, 50, 0, 1, images_hudvinheta_31_0_0, 1};
static Animation anim_hudvinheta_31_0 = {&direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, NULL, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0, &direction_hudvinheta_31_0_0};
static Animation * anim_array_hudvinheta_31[1] = {&anim_hudvinheta_31_0};
static Animations anim_hudvinheta_31 = {1, &anim_array_hudvinheta_31[0]};
static bool anim_hudvinheta_31_initialized;
class HUDVinheta_31 : public Active
{
public:
    HUDVinheta_31(int x, int y) : Active(x, y, HUDVinheta_31_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - Vinheta", 13);
#endif
        this->animations = &anim_hudvinheta_31;
        if (!anim_hudvinheta_31_initialized) {
            anim_hudvinheta_31_initialized = true;
            images_hudvinheta_31_0_0[0] = get_internal_image(29);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_hudvinheta_31(int x, int y)
{
    return new (Active::pool.create()) HUDVinheta_31(x, y);
}
static Image* images_escolhernoitehud_32_0_0[1];
static Direction direction_escolhernoitehud_32_0_0 = {0, 50, 50, 0, 1, images_escolhernoitehud_32_0_0, 1};
static Animation anim_escolhernoitehud_32_0 = {&direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, NULL, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0, &direction_escolhernoitehud_32_0_0};
static Animation * anim_array_escolhernoitehud_32[1] = {&anim_escolhernoitehud_32_0};
static Animations anim_escolhernoitehud_32 = {1, &anim_array_escolhernoitehud_32[0]};
static bool anim_escolhernoitehud_32_initialized;
class ESCOLHERNOITEHud_32 : public Active
{
public:
    ESCOLHERNOITEHud_32(int x, int y) : Active(x, y, ESCOLHERNOITEHud_32_type)
    {
        // qualifiers: 15
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - Hud", 20);
#endif
        this->animations = &anim_escolhernoitehud_32;
        if (!anim_escolhernoitehud_32_initialized) {
            anim_escolhernoitehud_32_initialized = true;
            images_escolhernoitehud_32_0_0[0] = get_internal_image(49);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(6, 255);
    }
};
FrameObject * create_escolhernoitehud_32(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITEHud_32(x, y);
}
static Image* images_escolheropespontocentral_33_0_0[1];
static Direction direction_escolheropespontocentral_33_0_0 = {0, 50, 50, 0, 1, images_escolheropespontocentral_33_0_0, 1};
static Animation anim_escolheropespontocentral_33_0 = {&direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, NULL, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0, &direction_escolheropespontocentral_33_0_0};
static Animation * anim_array_escolheropespontocentral_33[1] = {&anim_escolheropespontocentral_33_0};
static Animations anim_escolheropespontocentral_33 = {1, &anim_array_escolheropespontocentral_33[0]};
static bool anim_escolheropespontocentral_33_initialized;
class ESCOLHEROPESPontoCentral_33 : public Active
{
public:
    ESCOLHEROPESPontoCentral_33(int x, int y) : Active(x, y, ESCOLHEROPESPontoCentral_33_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("ESCOLHER OP\303\207\303\225ES - Ponto Central", 33);
#endif
        set_visible(false);
        this->animations = &anim_escolheropespontocentral_33;
        if (!anim_escolheropespontocentral_33_initialized) {
            anim_escolheropespontocentral_33_initialized = true;
            images_escolheropespontocentral_33_0_0[0] = get_internal_image(44);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_escolheropespontocentral_33(int x, int y)
{
    return new (Active::pool.create()) ESCOLHEROPESPontoCentral_33(x, y);
}
static Image* images_escolhernoitenoites_34_0_0[6];
static Direction direction_escolhernoitenoites_34_0_0 = {0, 0, 0, 0, -1, images_escolhernoitenoites_34_0_0, 6};
static Animation anim_escolhernoitenoites_34_0 = {&direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, NULL, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0, &direction_escolhernoitenoites_34_0_0};
static Animation * anim_array_escolhernoitenoites_34[1] = {&anim_escolhernoitenoites_34_0};
static Animations anim_escolhernoitenoites_34 = {1, &anim_array_escolhernoitenoites_34[0]};
static bool anim_escolhernoitenoites_34_initialized;
class ESCOLHERNOITENoites_34 : public Active
{
public:
    ESCOLHERNOITENoites_34(int x, int y) : Active(x, y, ESCOLHERNOITENoites_34_type)
    {
        // qualifiers: 15
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - Noites", 23);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_escolhernoitenoites_34;
        if (!anim_escolhernoitenoites_34_initialized) {
            anim_escolhernoitenoites_34_initialized = true;
            images_escolhernoitenoites_34_0_0[0] = get_internal_image(36);
            images_escolhernoitenoites_34_0_0[1] = get_internal_image(30);
            images_escolhernoitenoites_34_0_0[2] = get_internal_image(37);
            images_escolhernoitenoites_34_0_0[3] = get_internal_image(38);
            images_escolhernoitenoites_34_0_0[4] = get_internal_image(39);
            images_escolhernoitenoites_34_0_0[5] = get_internal_image(40);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(3, 100);
        alterables->values.set(4, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_escolhernoitenoites_34(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITENoites_34(x, y);
}
static Image* images_escolhernoitetrocarfrente_35_0_0[1];
static Direction direction_escolhernoitetrocarfrente_35_0_0 = {0, 50, 50, 0, 1, images_escolhernoitetrocarfrente_35_0_0, 1};
static Animation anim_escolhernoitetrocarfrente_35_0 = {&direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, NULL, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0, &direction_escolhernoitetrocarfrente_35_0_0};
static Animation * anim_array_escolhernoitetrocarfrente_35[1] = {&anim_escolhernoitetrocarfrente_35_0};
static Animations anim_escolhernoitetrocarfrente_35 = {1, &anim_array_escolhernoitetrocarfrente_35[0]};
static bool anim_escolhernoitetrocarfrente_35_initialized;
class ESCOLHERNOITETrocarFrente_35 : public Active
{
public:
    ESCOLHERNOITETrocarFrente_35(int x, int y) : Active(x, y, ESCOLHERNOITETrocarFrente_35_type)
    {
        // qualifiers: 15, 60, 91
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - TrocarFrente", 29);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_escolhernoitetrocarfrente_35;
        if (!anim_escolhernoitetrocarfrente_35_initialized) {
            anim_escolhernoitetrocarfrente_35_initialized = true;
            images_escolhernoitetrocarfrente_35_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_escolhernoitetrocarfrente_35(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITETrocarFrente_35(x, y);
}
static Image* images_escolhernoitetrocartrs_36_0_0[1];
static Direction direction_escolhernoitetrocartrs_36_0_0 = {0, 50, 50, 0, 1, images_escolhernoitetrocartrs_36_0_0, 1};
static Animation anim_escolhernoitetrocartrs_36_0 = {&direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, NULL, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0, &direction_escolhernoitetrocartrs_36_0_0};
static Animation * anim_array_escolhernoitetrocartrs_36[1] = {&anim_escolhernoitetrocartrs_36_0};
static Animations anim_escolhernoitetrocartrs_36 = {1, &anim_array_escolhernoitetrocartrs_36[0]};
static bool anim_escolhernoitetrocartrs_36_initialized;
class ESCOLHERNOITETrocarTrS_36 : public Active
{
public:
    ESCOLHERNOITETrocarTrS_36(int x, int y) : Active(x, y, ESCOLHERNOITETrocarTrS_36_type)
    {
        // qualifiers: 15, 60, 91
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - TrocarTr\303\241s", 28);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_escolhernoitetrocartrs_36;
        if (!anim_escolhernoitetrocartrs_36_initialized) {
            anim_escolhernoitetrocartrs_36_initialized = true;
            images_escolhernoitetrocartrs_36_0_0[0] = get_internal_image(42);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_escolhernoitetrocartrs_36(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITETrocarTrS_36(x, y);
}
static Image* images_escolhernoitevoltar_37_0_0[1];
static Direction direction_escolhernoitevoltar_37_0_0 = {0, 50, 50, 0, 1, images_escolhernoitevoltar_37_0_0, 1};
static Animation anim_escolhernoitevoltar_37_0 = {&direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, NULL, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0, &direction_escolhernoitevoltar_37_0_0};
static Animation * anim_array_escolhernoitevoltar_37[1] = {&anim_escolhernoitevoltar_37_0};
static Animations anim_escolhernoitevoltar_37 = {1, &anim_array_escolhernoitevoltar_37[0]};
static bool anim_escolhernoitevoltar_37_initialized;
class ESCOLHERNOITEVoltar_37 : public Active
{
public:
    ESCOLHERNOITEVoltar_37(int x, int y) : Active(x, y, ESCOLHERNOITEVoltar_37_type)
    {
        // qualifiers: 15, 42, 91
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - Voltar", 23);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_escolhernoitevoltar_37;
        if (!anim_escolhernoitevoltar_37_initialized) {
            anim_escolhernoitevoltar_37_initialized = true;
            images_escolhernoitevoltar_37_0_0[0] = get_internal_image(12);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(1, 127);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_escolhernoitevoltar_37(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITEVoltar_37(x, y);
}
static Image* images_escolhernoiteindicadorvoltar_38_0_0[1];
static Direction direction_escolhernoiteindicadorvoltar_38_0_0 = {0, 50, 50, 0, 1, images_escolhernoiteindicadorvoltar_38_0_0, 1};
static Animation anim_escolhernoiteindicadorvoltar_38_0 = {&direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, NULL, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0, &direction_escolhernoiteindicadorvoltar_38_0_0};
static Animation * anim_array_escolhernoiteindicadorvoltar_38[1] = {&anim_escolhernoiteindicadorvoltar_38_0};
static Animations anim_escolhernoiteindicadorvoltar_38 = {1, &anim_array_escolhernoiteindicadorvoltar_38[0]};
static bool anim_escolhernoiteindicadorvoltar_38_initialized;
class ESCOLHERNOITEIndicadorVoltar_38 : public Active
{
public:
    ESCOLHERNOITEIndicadorVoltar_38(int x, int y) : Active(x, y, ESCOLHERNOITEIndicadorVoltar_38_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - IndicadorVoltar", 32);
#endif
        this->animations = &anim_escolhernoiteindicadorvoltar_38;
        if (!anim_escolhernoiteindicadorvoltar_38_initialized) {
            anim_escolhernoiteindicadorvoltar_38_initialized = true;
            images_escolhernoiteindicadorvoltar_38_0_0[0] = get_internal_image(11);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 37);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_escolhernoiteindicadorvoltar_38(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITEIndicadorVoltar_38(x, y);
}
static Image* images_escolhernoitestart_39_0_0[1];
static Direction direction_escolhernoitestart_39_0_0 = {0, 50, 50, 0, 1, images_escolhernoitestart_39_0_0, 1};
static Animation anim_escolhernoitestart_39_0 = {&direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, NULL, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0, &direction_escolhernoitestart_39_0_0};
static Animation * anim_array_escolhernoitestart_39[1] = {&anim_escolhernoitestart_39_0};
static Animations anim_escolhernoitestart_39 = {1, &anim_array_escolhernoitestart_39[0]};
static bool anim_escolhernoitestart_39_initialized;
class ESCOLHERNOITEStart_39 : public Active
{
public:
    ESCOLHERNOITEStart_39(int x, int y) : Active(x, y, ESCOLHERNOITEStart_39_type)
    {
        // qualifiers: 15, 57, 91
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - Start", 22);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_escolhernoitestart_39;
        if (!anim_escolhernoitestart_39_initialized) {
            anim_escolhernoitestart_39_initialized = true;
            images_escolhernoitestart_39_0_0[0] = get_internal_image(19);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_escolhernoitestart_39(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITEStart_39(x, y);
}
static Image* images_escolhernoiteselecionaropo_40_0_0[1];
static Direction direction_escolhernoiteselecionaropo_40_0_0 = {0, 50, 50, 0, 1, images_escolhernoiteselecionaropo_40_0_0, 1};
static Animation anim_escolhernoiteselecionaropo_40_0 = {&direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, NULL, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0, &direction_escolhernoiteselecionaropo_40_0_0};
static Animation * anim_array_escolhernoiteselecionaropo_40[1] = {&anim_escolhernoiteselecionaropo_40_0};
static Animations anim_escolhernoiteselecionaropo_40 = {1, &anim_array_escolhernoiteselecionaropo_40[0]};
static bool anim_escolhernoiteselecionaropo_40_initialized;
class ESCOLHERNOITESelecionarOpO_40 : public Active
{
public:
    ESCOLHERNOITESelecionarOpO_40(int x, int y) : Active(x, y, ESCOLHERNOITESelecionarOpO_40_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - Selecionar Op\303\247\303\243o", 35);
#endif
        set_visible(false);
        flags &= ~SCROLL;
        this->animations = &anim_escolhernoiteselecionaropo_40;
        if (!anim_escolhernoiteselecionaropo_40_initialized) {
            anim_escolhernoiteselecionaropo_40_initialized = true;
            images_escolhernoiteselecionaropo_40_0_0[0] = get_internal_image(50);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
    }
};
FrameObject * create_escolhernoiteselecionaropo_40(int x, int y)
{
    return new (Active::pool.create()) ESCOLHERNOITESelecionarOpO_40(x, y);
}
class ESCOLHERNOITEVerVariVel_41 : public Counter
{
public:
    ESCOLHERNOITEVerVariVel_41(int x, int y) : Counter(x, y, ESCOLHERNOITEVerVariVel_41_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("ESCOLHER NOITE - Ver Vari\303\241vel", 30);
#endif
        set_visible(false);
        flags &= ~SCROLL;
        width = 96;
        height = 32;
        type = IMAGE_COUNTER;
        static Image * counter_images[14];
        static bool initialized = false;
        if (!initialized) {
            initialized = true;
            counter_images[0] = get_internal_image(31);
            counter_images[1] = get_internal_image(32);
            counter_images[2] = get_internal_image(33);
            counter_images[3] = get_internal_image(34);
            counter_images[4] = get_internal_image(35);
            counter_images[5] = get_internal_image(41);
            counter_images[6] = get_internal_image(43);
            counter_images[7] = get_internal_image(45);
            counter_images[8] = get_internal_image(46);
            counter_images[9] = get_internal_image(47);
            counter_images[10] = get_internal_image(62);
            counter_images[11] = get_internal_image(63);
            counter_images[12] = get_internal_image(64);
            counter_images[13] = get_internal_image(65);
        }
        images = (Image**)&counter_images;
        image_count = 14;
        minimum = 0;
        maximum = 6;
        set(0);
    }
};
FrameObject * create_escolhernoitevervarivel_41(int x, int y)
{
    return new (Counter::pool.create()) ESCOLHERNOITEVerVariVel_41(x, y);
}
static Image* images_hojvoltar_42_0_0[1];
static Direction direction_hojvoltar_42_0_0 = {0, 50, 50, 0, 1, images_hojvoltar_42_0_0, 1};
static Animation anim_hojvoltar_42_0 = {&direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, NULL, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0, &direction_hojvoltar_42_0_0};
static Animation * anim_array_hojvoltar_42[1] = {&anim_hojvoltar_42_0};
static Animations anim_hojvoltar_42 = {1, &anim_array_hojvoltar_42[0]};
static bool anim_hojvoltar_42_initialized;
class HoJVoltar_42 : public Active
{
public:
    HoJVoltar_42(int x, int y) : Active(x, y, HoJVoltar_42_type)
    {
        // qualifiers: 16, 42, 92
#ifndef NDEBUG
        name = std::string("HoJ - Voltar", 12);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_hojvoltar_42;
        if (!anim_hojvoltar_42_initialized) {
            anim_hojvoltar_42_initialized = true;
            images_hojvoltar_42_0_0[0] = get_internal_image(12);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(1, 127);
    }
};
FrameObject * create_hojvoltar_42(int x, int y)
{
    return new (Active::pool.create()) HoJVoltar_42(x, y);
}
static Image* images_hojindicadorvoltar_43_0_0[1];
static Direction direction_hojindicadorvoltar_43_0_0 = {0, 50, 50, 0, 1, images_hojindicadorvoltar_43_0_0, 1};
static Animation anim_hojindicadorvoltar_43_0 = {&direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, NULL, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0, &direction_hojindicadorvoltar_43_0_0};
static Animation * anim_array_hojindicadorvoltar_43[1] = {&anim_hojindicadorvoltar_43_0};
static Animations anim_hojindicadorvoltar_43 = {1, &anim_array_hojindicadorvoltar_43[0]};
static bool anim_hojindicadorvoltar_43_initialized;
class HoJIndicadorVoltar_43 : public Active
{
public:
    HoJIndicadorVoltar_43(int x, int y) : Active(x, y, HoJIndicadorVoltar_43_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HoJ - IndicadorVoltar", 21);
#endif
        this->animations = &anim_hojindicadorvoltar_43;
        if (!anim_hojindicadorvoltar_43_initialized) {
            anim_hojindicadorvoltar_43_initialized = true;
            images_hojindicadorvoltar_43_0_0[0] = get_internal_image(11);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 37);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_hojindicadorvoltar_43(int x, int y)
{
    return new (Active::pool.create()) HoJIndicadorVoltar_43(x, y);
}
static Image* images_hojhostgame_44_0_0[1];
static Direction direction_hojhostgame_44_0_0 = {0, 50, 50, 0, 1, images_hojhostgame_44_0_0, 1};
static Animation anim_hojhostgame_44_0 = {&direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, NULL, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0, &direction_hojhostgame_44_0_0};
static Animation * anim_array_hojhostgame_44[1] = {&anim_hojhostgame_44_0};
static Animations anim_hojhostgame_44 = {1, &anim_array_hojhostgame_44[0]};
static bool anim_hojhostgame_44_initialized;
class HoJHostGame_44 : public Active
{
public:
    HoJHostGame_44(int x, int y) : Active(x, y, HoJHostGame_44_type)
    {
        // qualifiers: 16, 92
#ifndef NDEBUG
        name = std::string("HoJ - Host Game", 15);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_hojhostgame_44;
        if (!anim_hojhostgame_44_initialized) {
            anim_hojhostgame_44_initialized = true;
            images_hojhostgame_44_0_0[0] = get_internal_image(48);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(1, 313);
    }
};
FrameObject * create_hojhostgame_44(int x, int y)
{
    return new (Active::pool.create()) HoJHostGame_44(x, y);
}
static Image* images_hojjoingame_45_0_0[1];
static Direction direction_hojjoingame_45_0_0 = {0, 50, 50, 0, 1, images_hojjoingame_45_0_0, 1};
static Animation anim_hojjoingame_45_0 = {&direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, NULL, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0, &direction_hojjoingame_45_0_0};
static Animation * anim_array_hojjoingame_45[1] = {&anim_hojjoingame_45_0};
static Animations anim_hojjoingame_45 = {1, &anim_array_hojjoingame_45[0]};
static bool anim_hojjoingame_45_initialized;
class HoJJoinGame_45 : public Active
{
public:
    HoJJoinGame_45(int x, int y) : Active(x, y, HoJJoinGame_45_type)
    {
        // qualifiers: 16, 92
#ifndef NDEBUG
        name = std::string("HoJ - Join Game", 15);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_hojjoingame_45;
        if (!anim_hojjoingame_45_initialized) {
            anim_hojjoingame_45_initialized = true;
            images_hojjoingame_45_0_0[0] = get_internal_image(20);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(1, 306);
    }
};
FrameObject * create_hojjoingame_45(int x, int y)
{
    return new (Active::pool.create()) HoJJoinGame_45(x, y);
}
static Image* images_hojindicadorjoin_46_0_0[1];
static Direction direction_hojindicadorjoin_46_0_0 = {0, 50, 50, 0, 1, images_hojindicadorjoin_46_0_0, 1};
static Animation anim_hojindicadorjoin_46_0 = {&direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, NULL, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0, &direction_hojindicadorjoin_46_0_0};
static Animation * anim_array_hojindicadorjoin_46[1] = {&anim_hojindicadorjoin_46_0};
static Animations anim_hojindicadorjoin_46 = {1, &anim_array_hojindicadorjoin_46[0]};
static bool anim_hojindicadorjoin_46_initialized;
class HoJIndicadorJoin_46 : public Active
{
public:
    HoJIndicadorJoin_46(int x, int y) : Active(x, y, HoJIndicadorJoin_46_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HoJ - IndicadorJoin", 19);
#endif
        this->animations = &anim_hojindicadorjoin_46;
        if (!anim_hojindicadorjoin_46_initialized) {
            anim_hojindicadorjoin_46_initialized = true;
            images_hojindicadorjoin_46_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_hojindicadorjoin_46(int x, int y)
{
    return new (Active::pool.create()) HoJIndicadorJoin_46(x, y);
}
static Image* images_hojindicadorhost_47_0_0[1];
static Direction direction_hojindicadorhost_47_0_0 = {0, 50, 50, 0, 1, images_hojindicadorhost_47_0_0, 1};
static Animation anim_hojindicadorhost_47_0 = {&direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, NULL, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0, &direction_hojindicadorhost_47_0_0};
static Animation * anim_array_hojindicadorhost_47[1] = {&anim_hojindicadorhost_47_0};
static Animations anim_hojindicadorhost_47 = {1, &anim_array_hojindicadorhost_47[0]};
static bool anim_hojindicadorhost_47_initialized;
class HoJIndicadorHost_47 : public Active
{
public:
    HoJIndicadorHost_47(int x, int y) : Active(x, y, HoJIndicadorHost_47_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HoJ - IndicadorHost", 19);
#endif
        this->animations = &anim_hojindicadorhost_47;
        if (!anim_hojindicadorhost_47_initialized) {
            anim_hojindicadorhost_47_initialized = true;
            images_hojindicadorhost_47_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 98);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_hojindicadorhost_47(int x, int y)
{
    return new (Active::pool.create()) HoJIndicadorHost_47(x, y);
}
static Image* images_playershud_48_0_0[1];
static Direction direction_playershud_48_0_0 = {0, 50, 50, 0, 1, images_playershud_48_0_0, 1};
static Animation anim_playershud_48_0 = {&direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, NULL, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0, &direction_playershud_48_0_0};
static Animation * anim_array_playershud_48[1] = {&anim_playershud_48_0};
static Animations anim_playershud_48 = {1, &anim_array_playershud_48[0]};
static bool anim_playershud_48_initialized;
class PLAYERSHud_48 : public Active
{
public:
    PLAYERSHud_48(int x, int y) : Active(x, y, PLAYERSHud_48_type)
    {
        // qualifiers: 17
#ifndef NDEBUG
        name = std::string("PLAYERS - Hud", 13);
#endif
        this->animations = &anim_playershud_48;
        if (!anim_playershud_48_initialized) {
            anim_playershud_48_initialized = true;
            images_playershud_48_0_0[0] = get_internal_image(67);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(6, 255);
    }
};
FrameObject * create_playershud_48(int x, int y)
{
    return new (Active::pool.create()) PLAYERSHud_48(x, y);
}
static Image* images_hudfadegame_49_0_0[1];
static Direction direction_hudfadegame_49_0_0 = {0, 50, 50, 0, 1, images_hudfadegame_49_0_0, 1};
static Image* images_hudfadegame_49_0_16[1];
static Direction direction_hudfadegame_49_0_16 = {16, 50, 50, 0, 1, images_hudfadegame_49_0_16, 1};
static Animation anim_hudfadegame_49_0 = {&direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, NULL, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, &direction_hudfadegame_49_0_16, NULL, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0, &direction_hudfadegame_49_0_0};
static Animation * anim_array_hudfadegame_49[1] = {&anim_hudfadegame_49_0};
static Animations anim_hudfadegame_49 = {1, &anim_array_hudfadegame_49[0]};
static bool anim_hudfadegame_49_initialized;
class HUDFadeGame_49 : public Active
{
public:
    HUDFadeGame_49(int x, int y) : Active(x, y, HUDFadeGame_49_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("HUD - FadeGame", 14);
#endif
        this->animations = &anim_hudfadegame_49;
        if (!anim_hudfadegame_49_initialized) {
            anim_hudfadegame_49_initialized = true;
            images_hudfadegame_49_0_0[0] = get_internal_image(55);
            images_hudfadegame_49_0_16[0] = get_internal_image(76);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_hudfadegame_49(int x, int y)
{
    return new (Active::pool.create()) HUDFadeGame_49(x, y);
}
static Image* images_playersprximo_50_0_0[1];
static Direction direction_playersprximo_50_0_0 = {0, 50, 50, 0, 1, images_playersprximo_50_0_0, 1};
static Animation anim_playersprximo_50_0 = {&direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, NULL, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0, &direction_playersprximo_50_0_0};
static Animation * anim_array_playersprximo_50[1] = {&anim_playersprximo_50_0};
static Animations anim_playersprximo_50 = {1, &anim_array_playersprximo_50[0]};
static bool anim_playersprximo_50_initialized;
class PLAYERSPrXimo_50 : public Active
{
public:
    PLAYERSPrXimo_50(int x, int y) : Active(x, y, PLAYERSPrXimo_50_type)
    {
        // qualifiers: 17, 57, 93
#ifndef NDEBUG
        name = std::string("PLAYERS - Pr\303\263ximo", 18);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_playersprximo_50;
        if (!anim_playersprximo_50_initialized) {
            anim_playersprximo_50_initialized = true;
            images_playersprximo_50_0_0[0] = get_internal_image(52);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_playersprximo_50(int x, int y)
{
    return new (Active::pool.create()) PLAYERSPrXimo_50(x, y);
}
static Image* images_playerstrocarfrente_51_0_0[1];
static Direction direction_playerstrocarfrente_51_0_0 = {0, 50, 50, 0, 1, images_playerstrocarfrente_51_0_0, 1};
static Animation anim_playerstrocarfrente_51_0 = {&direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, NULL, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0, &direction_playerstrocarfrente_51_0_0};
static Animation * anim_array_playerstrocarfrente_51[1] = {&anim_playerstrocarfrente_51_0};
static Animations anim_playerstrocarfrente_51 = {1, &anim_array_playerstrocarfrente_51[0]};
static bool anim_playerstrocarfrente_51_initialized;
class PLAYERSTrocarFrente_51 : public Active
{
public:
    PLAYERSTrocarFrente_51(int x, int y) : Active(x, y, PLAYERSTrocarFrente_51_type)
    {
        // qualifiers: 17, 60, 93
#ifndef NDEBUG
        name = std::string("PLAYERS - TrocarFrente", 22);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_playerstrocarfrente_51;
        if (!anim_playerstrocarfrente_51_initialized) {
            anim_playerstrocarfrente_51_initialized = true;
            images_playerstrocarfrente_51_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_playerstrocarfrente_51(int x, int y)
{
    return new (Active::pool.create()) PLAYERSTrocarFrente_51(x, y);
}
static Image* images_playerstrocartrs_52_0_0[1];
static Direction direction_playerstrocartrs_52_0_0 = {0, 50, 50, 0, 1, images_playerstrocartrs_52_0_0, 1};
static Animation anim_playerstrocartrs_52_0 = {&direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, NULL, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0, &direction_playerstrocartrs_52_0_0};
static Animation * anim_array_playerstrocartrs_52[1] = {&anim_playerstrocartrs_52_0};
static Animations anim_playerstrocartrs_52 = {1, &anim_array_playerstrocartrs_52[0]};
static bool anim_playerstrocartrs_52_initialized;
class PLAYERSTrocarTrS_52 : public Active
{
public:
    PLAYERSTrocarTrS_52(int x, int y) : Active(x, y, PLAYERSTrocarTrS_52_type)
    {
        // qualifiers: 17, 60, 93
#ifndef NDEBUG
        name = std::string("PLAYERS - TrocarTr\303\241s", 21);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_playerstrocartrs_52;
        if (!anim_playerstrocartrs_52_initialized) {
            anim_playerstrocartrs_52_initialized = true;
            images_playerstrocartrs_52_0_0[0] = get_internal_image(42);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_playerstrocartrs_52(int x, int y)
{
    return new (Active::pool.create()) PLAYERSTrocarTrS_52(x, y);
}
static Image* images_playersvoltar_53_0_0[1];
static Direction direction_playersvoltar_53_0_0 = {0, 50, 50, 0, 1, images_playersvoltar_53_0_0, 1};
static Animation anim_playersvoltar_53_0 = {&direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, NULL, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0, &direction_playersvoltar_53_0_0};
static Animation * anim_array_playersvoltar_53[1] = {&anim_playersvoltar_53_0};
static Animations anim_playersvoltar_53 = {1, &anim_array_playersvoltar_53[0]};
static bool anim_playersvoltar_53_initialized;
class PLAYERSVoltar_53 : public Active
{
public:
    PLAYERSVoltar_53(int x, int y) : Active(x, y, PLAYERSVoltar_53_type)
    {
        // qualifiers: 17, 42, 93
#ifndef NDEBUG
        name = std::string("PLAYERS - Voltar", 16);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_playersvoltar_53;
        if (!anim_playersvoltar_53_initialized) {
            anim_playersvoltar_53_initialized = true;
            images_playersvoltar_53_0_0[0] = get_internal_image(12);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(1, 127);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_playersvoltar_53(int x, int y)
{
    return new (Active::pool.create()) PLAYERSVoltar_53(x, y);
}
static Image* images_playersindicadorvoltar_54_0_0[1];
static Direction direction_playersindicadorvoltar_54_0_0 = {0, 50, 50, 0, 1, images_playersindicadorvoltar_54_0_0, 1};
static Animation anim_playersindicadorvoltar_54_0 = {&direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, NULL, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0, &direction_playersindicadorvoltar_54_0_0};
static Animation * anim_array_playersindicadorvoltar_54[1] = {&anim_playersindicadorvoltar_54_0};
static Animations anim_playersindicadorvoltar_54 = {1, &anim_array_playersindicadorvoltar_54[0]};
static bool anim_playersindicadorvoltar_54_initialized;
class PLAYERSIndicadorVoltar_54 : public Active
{
public:
    PLAYERSIndicadorVoltar_54(int x, int y) : Active(x, y, PLAYERSIndicadorVoltar_54_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("PLAYERS - IndicadorVoltar", 25);
#endif
        this->animations = &anim_playersindicadorvoltar_54;
        if (!anim_playersindicadorvoltar_54_initialized) {
            anim_playersindicadorvoltar_54_initialized = true;
            images_playersindicadorvoltar_54_0_0[0] = get_internal_image(11);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 37);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_playersindicadorvoltar_54(int x, int y)
{
    return new (Active::pool.create()) PLAYERSIndicadorVoltar_54(x, y);
}
static Image* images_playersselecionaropo_55_0_0[1];
static Direction direction_playersselecionaropo_55_0_0 = {0, 50, 50, 0, 1, images_playersselecionaropo_55_0_0, 1};
static Animation anim_playersselecionaropo_55_0 = {&direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, NULL, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0, &direction_playersselecionaropo_55_0_0};
static Animation * anim_array_playersselecionaropo_55[1] = {&anim_playersselecionaropo_55_0};
static Animations anim_playersselecionaropo_55 = {1, &anim_array_playersselecionaropo_55[0]};
static bool anim_playersselecionaropo_55_initialized;
class PLAYERSSelecionarOpO_55 : public Active
{
public:
    PLAYERSSelecionarOpO_55(int x, int y) : Active(x, y, PLAYERSSelecionarOpO_55_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("PLAYERS - Selecionar Op\303\247\303\243o", 28);
#endif
        set_visible(false);
        flags &= ~SCROLL;
        this->animations = &anim_playersselecionaropo_55;
        if (!anim_playersselecionaropo_55_initialized) {
            anim_playersselecionaropo_55_initialized = true;
            images_playersselecionaropo_55_0_0[0] = get_internal_image(71);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
    }
};
FrameObject * create_playersselecionaropo_55(int x, int y)
{
    return new (Active::pool.create()) PLAYERSSelecionarOpO_55(x, y);
}
static Image* images_playersnumero_56_0_0[7];
static Direction direction_playersnumero_56_0_0 = {0, 0, 0, 0, -1, images_playersnumero_56_0_0, 7};
static Animation anim_playersnumero_56_0 = {&direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, NULL, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0, &direction_playersnumero_56_0_0};
static Animation * anim_array_playersnumero_56[1] = {&anim_playersnumero_56_0};
static Animations anim_playersnumero_56 = {1, &anim_array_playersnumero_56[0]};
static bool anim_playersnumero_56_initialized;
class PLAYERSNumero_56 : public Active
{
public:
    PLAYERSNumero_56(int x, int y) : Active(x, y, PLAYERSNumero_56_type)
    {
        // qualifiers: 17
#ifndef NDEBUG
        name = std::string("PLAYERS - Numero", 16);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_playersnumero_56;
        if (!anim_playersnumero_56_initialized) {
            anim_playersnumero_56_initialized = true;
            images_playersnumero_56_0_0[0] = get_internal_image(53);
            images_playersnumero_56_0_0[1] = get_internal_image(68);
            images_playersnumero_56_0_0[2] = get_internal_image(58);
            images_playersnumero_56_0_0[3] = get_internal_image(61);
            images_playersnumero_56_0_0[4] = get_internal_image(59);
            images_playersnumero_56_0_0[5] = get_internal_image(60);
            images_playersnumero_56_0_0[6] = get_internal_image(66);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(3, 100);
        alterables->values.set(4, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_playersnumero_56(int x, int y)
{
    return new (Active::pool.create()) PLAYERSNumero_56(x, y);
}
static Image* images_joinhud_57_0_0[1];
static Direction direction_joinhud_57_0_0 = {0, 50, 50, 0, 1, images_joinhud_57_0_0, 1};
static Animation anim_joinhud_57_0 = {&direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, NULL, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0, &direction_joinhud_57_0_0};
static Animation * anim_array_joinhud_57[1] = {&anim_joinhud_57_0};
static Animations anim_joinhud_57 = {1, &anim_array_joinhud_57[0]};
static bool anim_joinhud_57_initialized;
class JOINHud_57 : public Active
{
public:
    JOINHud_57(int x, int y) : Active(x, y, JOINHud_57_type)
    {
        // qualifiers: 18
#ifndef NDEBUG
        name = std::string("JOIN - Hud", 10);
#endif
        this->animations = &anim_joinhud_57;
        if (!anim_joinhud_57_initialized) {
            anim_joinhud_57_initialized = true;
            images_joinhud_57_0_0[0] = get_internal_image(69);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(6, 255);
    }
};
FrameObject * create_joinhud_57(int x, int y)
{
    return new (Active::pool.create()) JOINHud_57(x, y);
}
static Image* images_joinvoltar_58_0_0[1];
static Direction direction_joinvoltar_58_0_0 = {0, 50, 50, 0, 1, images_joinvoltar_58_0_0, 1};
static Animation anim_joinvoltar_58_0 = {&direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, NULL, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0, &direction_joinvoltar_58_0_0};
static Animation * anim_array_joinvoltar_58[1] = {&anim_joinvoltar_58_0};
static Animations anim_joinvoltar_58 = {1, &anim_array_joinvoltar_58[0]};
static bool anim_joinvoltar_58_initialized;
class JOINVoltar_58 : public Active
{
public:
    JOINVoltar_58(int x, int y) : Active(x, y, JOINVoltar_58_type)
    {
        // qualifiers: 18, 42, 94
#ifndef NDEBUG
        name = std::string("JOIN - Voltar", 13);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_joinvoltar_58;
        if (!anim_joinvoltar_58_initialized) {
            anim_joinvoltar_58_initialized = true;
            images_joinvoltar_58_0_0[0] = get_internal_image(12);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(1, 127);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_joinvoltar_58(int x, int y)
{
    return new (Active::pool.create()) JOINVoltar_58(x, y);
}
static Image* images_joinindicadorvoltar_59_0_0[1];
static Direction direction_joinindicadorvoltar_59_0_0 = {0, 50, 50, 0, 1, images_joinindicadorvoltar_59_0_0, 1};
static Animation anim_joinindicadorvoltar_59_0 = {&direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, NULL, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0, &direction_joinindicadorvoltar_59_0_0};
static Animation * anim_array_joinindicadorvoltar_59[1] = {&anim_joinindicadorvoltar_59_0};
static Animations anim_joinindicadorvoltar_59 = {1, &anim_array_joinindicadorvoltar_59[0]};
static bool anim_joinindicadorvoltar_59_initialized;
class JOINIndicadorVoltar_59 : public Active
{
public:
    JOINIndicadorVoltar_59(int x, int y) : Active(x, y, JOINIndicadorVoltar_59_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("JOIN - IndicadorVoltar", 22);
#endif
        this->animations = &anim_joinindicadorvoltar_59;
        if (!anim_joinindicadorvoltar_59_initialized) {
            anim_joinindicadorvoltar_59_initialized = true;
            images_joinindicadorvoltar_59_0_0[0] = get_internal_image(11);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 37);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_joinindicadorvoltar_59(int x, int y)
{
    return new (Active::pool.create()) JOINIndicadorVoltar_59(x, y);
}
class JOINIP_60 : public EditObject
{
public:
    JOINIP_60(int x, int y) : EditObject(x, y, JOINIP_60_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("JOIN - IP", 9);
#endif
        width = 512;
        height = 65;
        edit_flags |= PASSWORD;
    }
};
FrameObject * create_joinip_60(int x, int y)
{
    return new (EditObject::pool.create()) JOINIP_60(x, y);
}
static Image* images_joinhudip_61_0_0[1];
static Direction direction_joinhudip_61_0_0 = {0, 50, 50, 0, 1, images_joinhudip_61_0_0, 1};
static Animation anim_joinhudip_61_0 = {&direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, NULL, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0, &direction_joinhudip_61_0_0};
static Animation * anim_array_joinhudip_61[1] = {&anim_joinhudip_61_0};
static Animations anim_joinhudip_61 = {1, &anim_array_joinhudip_61[0]};
static bool anim_joinhudip_61_initialized;
class JOINHudIP_61 : public Active
{
public:
    JOINHudIP_61(int x, int y) : Active(x, y, JOINHudIP_61_type)
    {
        // qualifiers: 18
#ifndef NDEBUG
        name = std::string("JOIN - HudIP", 12);
#endif
        this->animations = &anim_joinhudip_61;
        if (!anim_joinhudip_61_initialized) {
            anim_joinhudip_61_initialized = true;
            images_joinhudip_61_0_0[0] = get_internal_image(1);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(6, 255);
    }
};
FrameObject * create_joinhudip_61(int x, int y)
{
    return new (Active::pool.create()) JOINHudIP_61(x, y);
}
static Image* images_joinstart_62_0_0[1];
static Direction direction_joinstart_62_0_0 = {0, 50, 50, 0, 1, images_joinstart_62_0_0, 1};
static Animation anim_joinstart_62_0 = {&direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, NULL, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0, &direction_joinstart_62_0_0};
static Animation * anim_array_joinstart_62[1] = {&anim_joinstart_62_0};
static Animations anim_joinstart_62 = {1, &anim_array_joinstart_62[0]};
static bool anim_joinstart_62_initialized;
class JOINStart_62 : public Active
{
public:
    JOINStart_62(int x, int y) : Active(x, y, JOINStart_62_type)
    {
        // qualifiers: 18, 57, 94
#ifndef NDEBUG
        name = std::string("JOIN - Start", 12);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_joinstart_62;
        if (!anim_joinstart_62_initialized) {
            anim_joinstart_62_initialized = true;
            images_joinstart_62_0_0[0] = get_internal_image(72);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
        alterables->values.set(6, 255);
    }
};
FrameObject * create_joinstart_62(int x, int y)
{
    return new (Active::pool.create()) JOINStart_62(x, y);
}
static Image* images_loadingfundo_63_0_0[1];
static Direction direction_loadingfundo_63_0_0 = {0, 50, 50, 0, 1, images_loadingfundo_63_0_0, 1};
static Animation anim_loadingfundo_63_0 = {&direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, NULL, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0, &direction_loadingfundo_63_0_0};
static Animation * anim_array_loadingfundo_63[1] = {&anim_loadingfundo_63_0};
static Animations anim_loadingfundo_63 = {1, &anim_array_loadingfundo_63[0]};
static bool anim_loadingfundo_63_initialized;
class LOADINGFundo_63 : public Active
{
public:
    LOADINGFundo_63(int x, int y) : Active(x, y, LOADINGFundo_63_type)
    {
        // qualifiers: 26
#ifndef NDEBUG
        name = std::string("LOADING - Fundo", 15);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_loadingfundo_63;
        if (!anim_loadingfundo_63_initialized) {
            anim_loadingfundo_63_initialized = true;
            images_loadingfundo_63_0_0[0] = get_internal_image(70);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
    }
};
FrameObject * create_loadingfundo_63(int x, int y)
{
    return new (Active::pool.create()) LOADINGFundo_63(x, y);
}
static Image* images_loadingtexto_64_0_0[1];
static Direction direction_loadingtexto_64_0_0 = {0, 50, 50, 0, 1, images_loadingtexto_64_0_0, 1};
static Animation anim_loadingtexto_64_0 = {&direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, NULL, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0, &direction_loadingtexto_64_0_0};
static Animation * anim_array_loadingtexto_64[1] = {&anim_loadingtexto_64_0};
static Animations anim_loadingtexto_64 = {1, &anim_array_loadingtexto_64[0]};
static bool anim_loadingtexto_64_initialized;
class LOADINGTexto_64 : public Active
{
public:
    LOADINGTexto_64(int x, int y) : Active(x, y, LOADINGTexto_64_type)
    {
        // qualifiers: 26
#ifndef NDEBUG
        name = std::string("LOADING - Texto", 15);
#endif
        this->animations = &anim_loadingtexto_64;
        if (!anim_loadingtexto_64_initialized) {
            anim_loadingtexto_64_initialized = true;
            images_loadingtexto_64_0_0[0] = get_internal_image(75);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 1);
    }
};
FrameObject * create_loadingtexto_64(int x, int y)
{
    return new (Active::pool.create()) LOADINGTexto_64(x, y);
}
static Image* images_menucolisobotogamejolt_68_0_0[1];
static Direction direction_menucolisobotogamejolt_68_0_0 = {0, 50, 50, 0, 1, images_menucolisobotogamejolt_68_0_0, 1};
static Animation anim_menucolisobotogamejolt_68_0 = {&direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, NULL, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0, &direction_menucolisobotogamejolt_68_0_0};
static Animation * anim_array_menucolisobotogamejolt_68[1] = {&anim_menucolisobotogamejolt_68_0};
static Animations anim_menucolisobotogamejolt_68 = {1, &anim_array_menucolisobotogamejolt_68[0]};
static bool anim_menucolisobotogamejolt_68_initialized;
class MENUColisOBotOGamejolt_68 : public Active
{
public:
    MENUColisOBotOGamejolt_68(int x, int y) : Active(x, y, MENUColisOBotOGamejolt_68_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("MENU - Colis\303\243oBot\303\243oGamejolt", 29);
#endif
        set_visible(false);
        this->animations = &anim_menucolisobotogamejolt_68;
        if (!anim_menucolisobotogamejolt_68_initialized) {
            anim_menucolisobotogamejolt_68_initialized = true;
            images_menucolisobotogamejolt_68_0_0[0] = get_internal_image(77);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
    }
};
FrameObject * create_menucolisobotogamejolt_68(int x, int y)
{
    return new (Active::pool.create()) MENUColisOBotOGamejolt_68(x, y);
}
class Ini_70 : public INI
{
public:
    Ini_70(int x, int y) : INI(x, y, Ini_70_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("Ini", 3);
#endif
        auto_save = true;
        is_global = false;
        data = new SectionMap();
    }
};
FrameObject * create_ini_70(int x, int y)
{
    return new (INI::pool.create()) Ini_70(x, y);
}
static Image* images_opesindicadorgrficos_71_0_0[1];
static Direction direction_opesindicadorgrficos_71_0_0 = {0, 50, 50, 0, 1, images_opesindicadorgrficos_71_0_0, 1};
static Animation anim_opesindicadorgrficos_71_0 = {&direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, NULL, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0, &direction_opesindicadorgrficos_71_0_0};
static Animation * anim_array_opesindicadorgrficos_71[1] = {&anim_opesindicadorgrficos_71_0};
static Animations anim_opesindicadorgrficos_71 = {1, &anim_array_opesindicadorgrficos_71[0]};
static bool anim_opesindicadorgrficos_71_initialized;
class OPESIndicadorGrFicos_71 : public Active
{
public:
    OPESIndicadorGrFicos_71(int x, int y) : Active(x, y, OPESIndicadorGrFicos_71_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - IndicadorGr\303\241ficos", 29);
#endif
        this->animations = &anim_opesindicadorgrficos_71;
        if (!anim_opesindicadorgrficos_71_initialized) {
            anim_opesindicadorgrficos_71_initialized = true;
            images_opesindicadorgrficos_71_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 866);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_opesindicadorgrficos_71(int x, int y)
{
    return new (Active::pool.create()) OPESIndicadorGrFicos_71(x, y);
}
static Image* images_opesindicadorrenderapi_72_0_0[1];
static Direction direction_opesindicadorrenderapi_72_0_0 = {0, 50, 50, 0, 1, images_opesindicadorrenderapi_72_0_0, 1};
static Animation anim_opesindicadorrenderapi_72_0 = {&direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, NULL, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0, &direction_opesindicadorrenderapi_72_0_0};
static Animation * anim_array_opesindicadorrenderapi_72[1] = {&anim_opesindicadorrenderapi_72_0};
static Animations anim_opesindicadorrenderapi_72 = {1, &anim_array_opesindicadorrenderapi_72[0]};
static bool anim_opesindicadorrenderapi_72_initialized;
class OPESIndicadorRenderAPI_72 : public Active
{
public:
    OPESIndicadorRenderAPI_72(int x, int y) : Active(x, y, OPESIndicadorRenderAPI_72_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - IndicadorRenderAPI", 29);
#endif
        this->animations = &anim_opesindicadorrenderapi_72;
        if (!anim_opesindicadorrenderapi_72_initialized) {
            anim_opesindicadorrenderapi_72_initialized = true;
            images_opesindicadorrenderapi_72_0_0[0] = get_internal_image(10);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 866);
        alterables->values.set(2, 255);
    }
};
FrameObject * create_opesindicadorrenderapi_72(int x, int y)
{
    return new (Active::pool.create()) OPESIndicadorRenderAPI_72(x, y);
}
static Image* images_opesgrficos_73_0_0[1];
static Direction direction_opesgrficos_73_0_0 = {0, 50, 50, 0, 1, images_opesgrficos_73_0_0, 1};
static Animation anim_opesgrficos_73_0 = {&direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, NULL, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0, &direction_opesgrficos_73_0_0};
static Animation * anim_array_opesgrficos_73[1] = {&anim_opesgrficos_73_0};
static Animations anim_opesgrficos_73 = {1, &anim_array_opesgrficos_73[0]};
static bool anim_opesgrficos_73_initialized;
class OPESGrFicos_73 : public Active
{
public:
    OPESGrFicos_73(int x, int y) : Active(x, y, OPESGrFicos_73_type)
    {
        // qualifiers: 19, 95
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Gr\303\241ficos", 20);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_opesgrficos_73;
        if (!anim_opesgrficos_73_initialized) {
            anim_opesgrficos_73_initialized = true;
            images_opesgrficos_73_0_0[0] = get_internal_image(56);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 896);
    }
};
FrameObject * create_opesgrficos_73(int x, int y)
{
    return new (Active::pool.create()) OPESGrFicos_73(x, y);
}
static Image* images_opesrenderapi_74_0_0[1];
static Direction direction_opesrenderapi_74_0_0 = {0, 50, 50, 0, 1, images_opesrenderapi_74_0_0, 1};
static Animation anim_opesrenderapi_74_0 = {&direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, NULL, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0, &direction_opesrenderapi_74_0_0};
static Animation * anim_array_opesrenderapi_74[1] = {&anim_opesrenderapi_74_0};
static Animations anim_opesrenderapi_74 = {1, &anim_array_opesrenderapi_74[0]};
static bool anim_opesrenderapi_74_initialized;
class OPESRenderAPI_74 : public Active
{
public:
    OPESRenderAPI_74(int x, int y) : Active(x, y, OPESRenderAPI_74_type)
    {
        // qualifiers: 19, 95
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Render API", 21);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_opesrenderapi_74;
        if (!anim_opesrenderapi_74_initialized) {
            anim_opesrenderapi_74_initialized = true;
            images_opesrenderapi_74_0_0[0] = get_internal_image(57);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 896);
    }
};
FrameObject * create_opesrenderapi_74(int x, int y)
{
    return new (Active::pool.create()) OPESRenderAPI_74(x, y);
}
static Image* images_opesbotogrficos_75_0_0[5];
static Direction direction_opesbotogrficos_75_0_0 = {0, 0, 0, 0, -1, images_opesbotogrficos_75_0_0, 5};
static Animation anim_opesbotogrficos_75_0 = {&direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, NULL, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0, &direction_opesbotogrficos_75_0_0};
static Animation * anim_array_opesbotogrficos_75[1] = {&anim_opesbotogrficos_75_0};
static Animations anim_opesbotogrficos_75 = {1, &anim_array_opesbotogrficos_75[0]};
static bool anim_opesbotogrficos_75_initialized;
class OPESBotOGrFicos_75 : public Active
{
public:
    OPESBotOGrFicos_75(int x, int y) : Active(x, y, OPESBotOGrFicos_75_type)
    {
        // qualifiers: 19
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Bot\303\243o Gr\303\241ficos", 27);
#endif
        this->animations = &anim_opesbotogrficos_75;
        if (!anim_opesbotogrficos_75_initialized) {
            anim_opesbotogrficos_75_initialized = true;
            images_opesbotogrficos_75_0_0[0] = get_internal_image(84);
            images_opesbotogrficos_75_0_0[1] = get_internal_image(85);
            images_opesbotogrficos_75_0_0[2] = get_internal_image(86);
            images_opesbotogrficos_75_0_0[3] = get_internal_image(87);
            images_opesbotogrficos_75_0_0[4] = get_internal_image(88);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 1247);
    }
};
FrameObject * create_opesbotogrficos_75(int x, int y)
{
    return new (Active::pool.create()) OPESBotOGrFicos_75(x, y);
}
static Image* images_opesbotorenderapi_76_0_0[2];
static Direction direction_opesbotorenderapi_76_0_0 = {0, 0, 0, 0, -1, images_opesbotorenderapi_76_0_0, 2};
static Animation anim_opesbotorenderapi_76_0 = {&direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, NULL, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0, &direction_opesbotorenderapi_76_0_0};
static Animation * anim_array_opesbotorenderapi_76[1] = {&anim_opesbotorenderapi_76_0};
static Animations anim_opesbotorenderapi_76 = {1, &anim_array_opesbotorenderapi_76[0]};
static bool anim_opesbotorenderapi_76_initialized;
class OPESBotORenderAPI_76 : public Active
{
public:
    OPESBotORenderAPI_76(int x, int y) : Active(x, y, OPESBotORenderAPI_76_type)
    {
        // qualifiers: 19
#ifndef NDEBUG
        name = std::string("OP\303\207\303\225ES - Bot\303\243o RenderAPI", 27);
#endif
        this->animations = &anim_opesbotorenderapi_76;
        if (!anim_opesbotorenderapi_76_initialized) {
            anim_opesbotorenderapi_76_initialized = true;
            images_opesbotorenderapi_76_0_0[0] = get_internal_image(89);
            images_opesbotorenderapi_76_0_0[1] = get_internal_image(18);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(false);
        create_alterables();
        alterables->values.set(0, 255);
        alterables->values.set(2, 1300);
    }
};
FrameObject * create_opesbotorenderapi_76(int x, int y)
{
    return new (Active::pool.create()) OPESBotORenderAPI_76(x, y);
}
static Image* images_miscbotovolume_77_0_0[6];
static Direction direction_miscbotovolume_77_0_0 = {0, 0, 0, 0, -1, images_miscbotovolume_77_0_0, 6};
static Animation anim_miscbotovolume_77_0 = {&direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, NULL, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0, &direction_miscbotovolume_77_0_0};
static Animation * anim_array_miscbotovolume_77[1] = {&anim_miscbotovolume_77_0};
static Animations anim_miscbotovolume_77 = {1, &anim_array_miscbotovolume_77[0]};
static bool anim_miscbotovolume_77_initialized;
class MISCBotOVolume_77 : public Active
{
public:
    MISCBotOVolume_77(int x, int y) : Active(x, y, MISCBotOVolume_77_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("MISC - Bot\303\243oVolume", 19);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_miscbotovolume_77;
        if (!anim_miscbotovolume_77_initialized) {
            anim_miscbotovolume_77_initialized = true;
            images_miscbotovolume_77_0_0[0] = get_internal_image(73);
            images_miscbotovolume_77_0_0[1] = get_internal_image(78);
            images_miscbotovolume_77_0_0[2] = get_internal_image(90);
            images_miscbotovolume_77_0_0[3] = get_internal_image(91);
            images_miscbotovolume_77_0_0[4] = get_internal_image(92);
            images_miscbotovolume_77_0_0[5] = get_internal_image(93);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 5);
        alterables->values.set(1, 1);
    }
};
FrameObject * create_miscbotovolume_77(int x, int y)
{
    return new (Active::pool.create()) MISCBotOVolume_77(x, y);
}
static Image* images_miscbotodiscord_78_0_0[1];
static Direction direction_miscbotodiscord_78_0_0 = {0, 50, 50, 0, 1, images_miscbotodiscord_78_0_0, 1};
static Animation anim_miscbotodiscord_78_0 = {&direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, NULL, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0, &direction_miscbotodiscord_78_0_0};
static Animation * anim_array_miscbotodiscord_78[1] = {&anim_miscbotodiscord_78_0};
static Animations anim_miscbotodiscord_78 = {1, &anim_array_miscbotodiscord_78[0]};
static bool anim_miscbotodiscord_78_initialized;
class MISCBotODiscord_78 : public Active
{
public:
    MISCBotODiscord_78(int x, int y) : Active(x, y, MISCBotODiscord_78_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("MISC - Bot\303\243oDiscord", 20);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_miscbotodiscord_78;
        if (!anim_miscbotodiscord_78_initialized) {
            anim_miscbotodiscord_78_initialized = true;
            images_miscbotodiscord_78_0_0[0] = get_internal_image(94);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
    }
};
FrameObject * create_miscbotodiscord_78(int x, int y)
{
    return new (Active::pool.create()) MISCBotODiscord_78(x, y);
}
static Image* images_miscbotoyt_79_0_0[1];
static Direction direction_miscbotoyt_79_0_0 = {0, 50, 50, 0, 1, images_miscbotoyt_79_0_0, 1};
static Animation anim_miscbotoyt_79_0 = {&direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, NULL, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0, &direction_miscbotoyt_79_0_0};
static Animation * anim_array_miscbotoyt_79[1] = {&anim_miscbotoyt_79_0};
static Animations anim_miscbotoyt_79 = {1, &anim_array_miscbotoyt_79[0]};
static bool anim_miscbotoyt_79_initialized;
class MISCBotOYT_79 : public Active
{
public:
    MISCBotOYT_79(int x, int y) : Active(x, y, MISCBotOYT_79_type)
    {
        // qualifiers: 
#ifndef NDEBUG
        name = std::string("MISC - Bot\303\243oYT", 15);
#endif
        flags &= ~SCROLL;
        this->animations = &anim_miscbotoyt_79;
        if (!anim_miscbotoyt_79_initialized) {
            anim_miscbotoyt_79_initialized = true;
            images_miscbotoyt_79_0_0[0] = get_internal_image(95);
        }
        active_flags |= TRANSPARENT;
        animation = STOPPED;
        current_animation = animation;
        initialize_active(true);
        create_alterables();
        alterables->values.set(0, 1);
    }
};
FrameObject * create_miscbotoyt_79(int x, int y)
{
    return new (Active::pool.create()) MISCBotOYT_79(x, y);
}
FRAMEOBJECT_IMPL(Active)
FRAMEOBJECT_IMPL(Counter)
FRAMEOBJECT_IMPL(FrameObject)
FRAMEOBJECT_IMPL(EditObject)
FRAMEOBJECT_IMPL(INI)

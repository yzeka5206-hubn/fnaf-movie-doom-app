inline static unsigned int
get_file_hash (register const char *str, register unsigned int len)
{
  return 0;
}


int get_file_id(const std::string & in)
{
    if (in.empty())
        return -1;
    unsigned int hash = get_file_hash(&in[0], in.size());
    switch (hash) {
        case 0: return FILE_DOHRMA_REGULAR_TTF_0;
    }
    return -1;
}


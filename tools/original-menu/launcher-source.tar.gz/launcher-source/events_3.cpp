#include "launcher_bridge.h"
#include "events.h"
#include "framedata.h"
#include "lists.h"
#include "media.h"
#include "objects.h"
#include "bitarray.h"

void Frames::event_func_193()
{
    // event 183_1
    {
        // group: Group 11
        if (!((global_values->get(0)) != (12))) goto event_183_1_end;
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.set(5, 0);
    }
    event_183_1_end: ;
}
void Frames::event_func_194()
{
    // event 184_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(7)) == (0))) goto event_184_1_end;
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(6, str_cl_graphicpreset_0_vid_scalefactor_0_5_gl_texture_filter_0_gl_light_shadowmap_0_gl_shadowmap_quality_128_gl_bloom_0_gl_lens_0_gl_ssao_0_gl_multisample_0_19);
    }
    event_184_1_end: ;
}
void Frames::event_func_195()
{
    // event 185_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(7)) == (1))) goto event_185_1_end;
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(6, str_cl_graphicpreset_1_vid_scalefactor_0_75_gl_texture_filter_2_gl_light_shadowmap_1_gl_shadowmap_quality_256_gl_bloom_0_gl_lens_0_gl_ssao_0_gl_multisample_0_20);
    }
    event_185_1_end: ;
}
void Frames::event_func_196()
{
    // event 186_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(7)) == (2))) goto event_186_1_end;
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(6, str_cl_graphicpreset_2_vid_scalefactor_1_0_gl_texture_filter_3_gl_light_shadowmap_1_gl_shadowmap_quality_512_gl_bloom_1_gl_lens_0_gl_ssao_1_gl_multisample_0_21);
    }
    event_186_1_end: ;
}
void Frames::event_func_197()
{
    // event 187_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(7)) == (3))) goto event_187_1_end;
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(6, str_cl_graphicpreset_3_vid_scalefactor_1_0_gl_texture_filter_4_gl_light_shadowmap_1_gl_shadowmap_quality_1024_gl_bloom_1_gl_lens_1_gl_ssao_1_gl_multisample_2_22);
    }
    event_187_1_end: ;
}
void Frames::event_func_198()
{
    // event 188_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(7)) == (4))) goto event_188_1_end;
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(6, str_cl_graphicpreset_4_vid_scalefactor_1_0_gl_texture_filter_4_gl_light_shadowmap_1_gl_shadowmap_quality_1024_gl_bloom_1_gl_lens_1_gl_ssao_1_gl_multisample_8_23);
    }
    event_188_1_end: ;
}
void Frames::event_func_199()
{
    // event 189_1
    {
        // group: Group 11
        if (!(((Active*)get_instance(escolhernoitestart_39_instances))->mouse_over() && is_mouse_pressed_once(SDL_BUTTON_LEFT))) goto event_189_1_end;
        if (!((((Active*)get_instance(bancodedadosinteraomenu_18_instances))->alterables->values.get(0)) == (0))) goto event_189_1_end;
        if (!(((Active*)get_instance(bancodedadosinteraomenu_18_instances))->alterables->flags.is_on(0))) goto event_189_1_end;
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.set(0, 2);
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.set(1, 0);
        ((Active*)get_instance(hudfadegame_49_instances))->set_direction(16);
        ((Active*)get_instance(loadingtexto_64_instances))->alterables->values.set(0, 0.5);
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(5, str_ev_ishalloween_24+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(6))+str_ev_ischristmas_25+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(5)));
        media.play_id(SOUND_CLICK_3, -1, 1);
        media.stop_sample(SOUND_STATIC2_5);
        media.stop_sample(SOUND_MENUSOURCEMANEIRO2_6);
        media.play_id(SOUND_CINEMATIC_BOOM_3_4, -1, 1);
    }
    event_189_1_end: ;
}
void Frames::event_func_200()
{
    // event 190_1
    {
        // group: Group 11
        if (!(((Active*)get_instance(escolhernoitestart_39_instances))->mouse_over() && is_mouse_pressed_once(SDL_BUTTON_LEFT))) goto event_190_1_end;
        if (!((((Active*)get_instance(bancodedadosinteraomenu_18_instances))->alterables->values.get(0)) == (0))) goto event_190_1_end;
        if (!(((Active*)get_instance(bancodedadosinteraomenu_18_instances))->alterables->flags.is_on(2))) goto event_190_1_end;
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.set(0, 3);
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.set(1, 0);
        ((Active*)get_instance(hudfadegame_49_instances))->set_direction(16);
        ((Active*)get_instance(loadingtexto_64_instances))->alterables->values.set(0, 0.5);
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(5, str_ev_ishalloween_24+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(6))+str_ev_ischristmas_25+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(5)));
        media.play_id(SOUND_CLICK_3, -1, 1);
        media.stop_sample(SOUND_STATIC2_5);
        media.stop_sample(SOUND_MENUSOURCEMANEIRO2_6);
        media.play_id(SOUND_CINEMATIC_BOOM_3_4, -1, 1);
    }
    event_190_1_end: ;
}
void Frames::event_func_201()
{
    // event 191_1
    {
        // group: Group 11
        if (!(((Active*)get_instance(joinstart_62_instances))->mouse_over() && is_mouse_pressed_once(SDL_BUTTON_LEFT))) goto event_191_1_end;
        if (!((((EditObject*)get_instance(joinip_60_instances))->alterables->strings.get(0)) != (empty_string))) goto event_191_1_end;
        if (!((((Active*)get_instance(bancodedadosinteraomenu_18_instances))->alterables->values.get(0)) == (0))) goto event_191_1_end;
        if (!(((Active*)get_instance(bancodedadosinteraomenu_18_instances))->alterables->flags.is_on(3))) goto event_191_1_end;
        ((EditObject*)get_instance(joinip_60_instances))->set_visible(false);
        ((EditObject*)get_instance(joinip_60_instances))->disable_focus();
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.set(0, 4);
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.set(1, 0);
        ((Active*)get_instance(hudfadegame_49_instances))->set_direction(16);
        ((Active*)get_instance(loadingtexto_64_instances))->alterables->values.set(0, 0.5);
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.set(5, str_ev_ishalloween_24+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(6))+str_ev_ischristmas_25+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(5)));
        media.play_id(SOUND_CLICK_3, -1, 1);
        media.stop_sample(SOUND_STATIC2_5);
        media.stop_sample(SOUND_MENUSOURCEMANEIRO2_6);
        media.play_id(SOUND_CINEMATIC_BOOM_3_4, -1, 1);
    }
    event_191_1_end: ;
}
void Frames::event_func_202()
{
    // event 192_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(0)) > (1))) goto event_192_1_end;
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(1)) < (255))) goto event_192_1_end;
        ((Active*)get_instance(hudfadegame_49_instances))->alterables->values.add(1, 15);
        qualifier_0.clear_selection();
        for (QualifierIterator it(qualifier_0); !it.end(); ++it) {
            ((Active*)*it)->set_visible(true);
        }
    }
    event_192_1_end: ;
}
void Frames::event_func_203()
{
    // event 193_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(0)) == (2))) goto event_193_1_end;
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(1)) >= (255))) goto event_193_1_end;
        if (not_always_193_1 > loop_count) {
            not_always_193_1 = loop_count + 2;
            goto event_193_1_end;
        }
        not_always_193_1 = loop_count + 2;
        schedule_named_timer(7000, str_fecharlauncher_26);
        // Original single-player selection, passed as validated typed values.
        Active *db = (Active*)get_instance(bancodedadoslauncher_17_instances);
        launcher_request_singleplayer(db->alterables->strings.get(0),
            db->alterables->values.get(3), db->alterables->values.get(4),
            db->alterables->values.get(7),
            ((Active*)get_instance(opesbotoshaders_25_instances))->alterables->values.get(1),
            db->alterables->values.get(6), db->alterables->values.get(5));
    }
    event_193_1_end: ;
}
void Frames::event_func_204()
{
    // event 194_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(0)) == (3))) goto event_194_1_end;
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(1)) >= (255))) goto event_194_1_end;
        if (not_always_194_1 > loop_count) {
            not_always_194_1 = loop_count + 2;
            goto event_194_1_end;
        }
        not_always_194_1 = loop_count + 2;
        schedule_named_timer(7000, str_fecharlauncher_26);
        runinconsole_0(str_start_engine_uz_uzdoom_exe_iwad_engine_fnafmovie_ipk3_27+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(3)+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(4)+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(1)+str_host_33+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(0))+str_map_34+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(0)+str_skill_1_netmode_0_sv_cheats_0_sv_difficulty_29+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(3))+str_sv_streamermode_30+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(4))+str_vid_preferbackend_31+number_to_string(((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.get(8))+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(6)+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(5)+str_port_5029_extratic_set_i_discordrpc_false_32, 0, 0, 0, 0);
    }
    event_194_1_end: ;
}
void Frames::event_func_205()
{
    // event 195_1
    {
        // group: Group 11
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(0)) == (4))) goto event_195_1_end;
        if (!((((Active*)get_instance(hudfadegame_49_instances))->alterables->values.get(1)) >= (255))) goto event_195_1_end;
        if (not_always_195_1 > loop_count) {
            not_always_195_1 = loop_count + 2;
            goto event_195_1_end;
        }
        not_always_195_1 = loop_count + 2;
        schedule_named_timer(7000, str_fecharlauncher_26);
        runinconsole_0(str_start_engine_uz_uzdoom_exe_iwad_engine_fnafmovie_ipk3_27+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(3)+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(4)+((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->strings.get(1)+str_join_35+((EditObject*)get_instance(joinip_60_instances))->alterables->strings.get(0), 0, 0, 0, 0);
    }
    event_195_1_end: ;
}
void Frames::event_func_206()
{
    // event 196_1
    {
        // group: Group 11
        if (!(consume_named_timer(str_fecharlauncher_26))) goto event_196_1_end;
        if (not_always_196_1 > loop_count) {
            not_always_196_1 = loop_count + 2;
            goto event_196_1_end;
        }
        not_always_196_1 = loop_count + 2;
        has_quit = true;
    }
    event_196_1_end: ;
}
void Frames::handle_frame_2_events()
{
    test_collisions_1();
    event_func_206();
    if (next_frame != -1) return;
    event_func_12();
    event_func_13();
    event_func_15();
    event_func_16();
    event_func_17();
    event_func_18();
    event_func_25();
    event_func_26();
    event_func_27();
    event_func_28();
    event_func_29();
    event_func_30();
    event_func_31();
    event_func_32();
    event_func_33();
    event_func_34();
    event_func_35();
    event_func_36();
    event_func_37();
    event_func_38();
    event_func_39();
    event_func_40();
    event_func_41();
    event_func_42();
    event_func_43();
    event_func_44();
    event_func_45();
    event_func_46();
    event_func_47();
    event_func_48();
    event_func_49();
    event_func_50();
    event_func_51();
    event_func_52();
    event_func_53();
    event_func_54();
    event_func_55();
    event_func_56();
    event_func_57();
    event_func_58();
    event_func_59();
    event_func_60();
    event_func_61();
    event_func_62();
    event_func_63();
    event_func_64();
    event_func_65();
    event_func_66();
    event_func_67();
    event_func_68();
    event_func_69();
    event_func_70();
    event_func_71();
    event_func_72();
    event_func_73();
    event_func_74();
    event_func_75();
    event_func_76();
    event_func_77();
    event_func_78();
    event_func_79();
    event_func_80();
    event_func_81();
    event_func_82();
    event_func_83();
    event_func_84();
    event_func_85();
    event_func_86();
    event_func_89();
    event_func_90();
    event_func_91();
    event_func_92();
    event_func_93();
    event_func_94();
    event_func_95();
    event_func_96();
    event_func_97();
    event_func_98();
    event_func_99();
    event_func_102();
    event_func_103();
    event_func_104();
    event_func_105();
    event_func_106();
    event_func_107();
    event_func_108();
    event_func_109();
    event_func_110();
    event_func_111();
    event_func_112();
    event_func_113();
    event_func_114();
    event_func_115();
    event_func_116();
    event_func_117();
    event_func_118();
    event_func_119();
    event_func_120();
    event_func_121();
    event_func_122();
    event_func_123();
    event_func_124();
    event_func_126();
    event_func_128();
    event_func_130();
    event_func_131();
    event_func_132();
    event_func_134();
    event_func_136();
    event_func_137();
    event_func_138();
    event_func_139();
    event_func_140();
    event_func_141();
    event_func_142();
    event_func_143();
    event_func_144();
    event_func_145();
    event_func_146();
    event_func_147();
    event_func_148();
    event_func_149();
    event_func_150();
    event_func_151();
    event_func_152();
    event_func_153();
    event_func_154();
    event_func_155();
    event_func_156();
    event_func_157();
    event_func_158();
    event_func_159();
    event_func_160();
    event_func_161();
    event_func_163();
    event_func_166();
    event_func_168();
    event_func_173();
    event_func_175();
    event_func_177();
    event_func_178();
    event_func_179();
    event_func_180();
    event_func_181();
    event_func_182();
    event_func_183();
    event_func_186();
    event_func_187();
    event_func_188();
    event_func_189();
    event_func_190();
    event_func_191();
    event_func_192();
    event_func_193();
    event_func_194();
    event_func_195();
    event_func_196();
    event_func_197();
    event_func_198();
    event_func_202();
    event_func_203();
    event_func_204();
    event_func_205();
}
void Frames::handle_frame_2_pre_events()
{
    event_func_14();
    event_func_19();
    event_func_20();
    event_func_21();
    event_func_22();
    event_func_23();
    event_func_24();
    event_func_87();
    event_func_88();
    event_func_100();
    event_func_101();
    event_func_125();
    event_func_127();
    event_func_129();
    event_func_133();
    event_func_135();
    event_func_162();
    event_func_164();
    event_func_165();
    event_func_167();
    event_func_169();
    event_func_170();
    event_func_171();
    event_func_172();
    event_func_174();
    event_func_176();
    event_func_184();
    event_func_185();
    event_func_199();
    event_func_200();
    event_func_201();
}
void Frames::event_func_207()
{
    // event 1_1
    {
        ((INI*)get_instance(ini_70_instances))->load_file(str_fnafdoommovieconfigs_36);
        ((INI*)get_instance(ini_70_instances))->set_item(str_dificuldade_4);
        ((INI*)get_instance(ini_70_instances))->set_item(str_streamer_mode_5);
        ((INI*)get_instance(ini_70_instances))->set_item(str_shaders_6);
        ((INI*)get_instance(ini_70_instances))->set_item(str_graficos_7);
        ((INI*)get_instance(ini_70_instances))->set_item(str_render_api_8);
        ((Active*)get_instance(miscbotovolume_77_instances))->alterables->values.set(0, ((INI*)get_instance(ini_70_instances))->get_value_int(str_volume_musica_9, 5));
        qualifier_0.clear_selection();
        for (QualifierIterator it(qualifier_0); !it.end(); ++it) {
            ((Active*)*it)->set_visible(false);
        }
        ((EditObject*)get_instance(joinip_60_instances))->set_visible(false);
        ((EditObject*)get_instance(joinip_60_instances))->disable_focus();
        manager.set_window(true);
        ((Active*)get_instance(hudbackground_7_instances))->alterables->values.set(1, random_inclusive(20, 40));
        escolhernoitenoites_34_instances.clear_selection();
        spread_value(escolhernoitenoites_34_instances, 0, 0);
        for (ObjectIterator it(escolhernoitenoites_34_instances); !it.end(); ++it) {
            ((Active*)*it)->alterables->values.set(2, 360*((Active*)*it)->alterables->values.get(0));
            ((Active*)*it)->alterables->values.set(4, escolhernoitenoites_34_instances.size());
            ((Active*)*it)->force_frame(((Active*)*it)->alterables->values.get(0));
        }
        playersnumero_56_instances.clear_selection();
        spread_value(playersnumero_56_instances, 0, 0);
        for (ObjectIterator it(playersnumero_56_instances); !it.end(); ++it) {
            ((Active*)*it)->alterables->values.set(2, 360*((Active*)*it)->alterables->values.get(0));
            ((Active*)*it)->alterables->values.set(4, playersnumero_56_instances.size());
            ((Active*)*it)->force_frame(((Active*)*it)->alterables->values.get(0));
        }
        media.play_id(SOUND_MENUSOURCEMANEIRO2_6, -1, 0);
        {
            FrameObject * parent = ((Active*)get_instance(joinhudip_61_instances));
            if (parent == NULL) goto pos_end_1_1_0;
            ((EditObject*)get_instance(joinip_60_instances))->set_global_position(parent->get_x() + 4, parent->get_y() + 4);
            pos_end_1_1_0: ;
        }
        
        
        
        media.play_id(SOUND_STATIC2_5, -1, 0);
        global_values->set(0, platform_get_datetime().mon);
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.set(3, ((INI*)get_instance(ini_70_instances))->get_value_int(str_dificuldade_4));
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.set(4, ((INI*)get_instance(ini_70_instances))->get_value_int(str_streamer_mode_5));
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.set(7, ((INI*)get_instance(ini_70_instances))->get_value_int(str_graficos_7));
        // Explicitly show the supported Android backend and missing add-on state.
        ((Active*)get_instance(bancodedadoslauncher_17_instances))->alterables->values.set(8, 0);
        ((Active*)get_instance(opesbotoshaders_25_instances))->alterables->values.set(1, 0);
        ((INI*)get_instance(ini_70_instances))->set_item(str_volume_musica_9);
    }
    event_1_1_end: ;
}
void Frames::on_frame_2_start_events()
{
    event_func_207();
}
void Frames::on_frame_2_init()
{
    index = 1;
    width = 1920;
    height = 1080;
    virtual_width = 1920;
    virtual_height = 1080;
    background_color = Color(255, 255, 255);
    timer_base = 60;
    reset_image_cache();
    flush_image_cache();
    layers.resize(10);
    layers[0].init(0, 1.0, 1.0, true, false, false);
    layers[1].init(1, 1.0, 1.0, true, false, false);
    layers[2].init(2, 1.0, 1.0, true, false, false);
    layers[3].init(3, 1.0, 1.0, true, false, false);
    layers[4].init(4, 1.0, 1.0, true, false, false);
    layers[5].init(5, 1.0, 1.0, true, false, false);
    layers[6].init(6, 1.0, 1.0, true, false, false);
    layers[7].init(7, 1.0, 1.0, true, false, false);
    layers[8].init(8, 1.0, 1.0, true, false, false);
    layers[9].init(9, 1.0, 1.0, true, false, false);
    #ifdef CHOWDREN_HAS_MRT
    #endif
    #ifdef CHOWDREN_IS_3DS
    #endif
    static ObjectList* qualifier_8_instances[] = {&opesvoltar_22_instances, &escolhernoitevoltar_37_instances, &hojvoltar_42_instances, &playersvoltar_53_instances, &joinvoltar_58_instances, NULL};
    qualifier_8.set(5, &qualifier_8_instances[0]);
    static ObjectList* qualifier_9_instances[] = {&escolhernoitetrocarfrente_35_instances, &escolhernoitetrocartrs_36_instances, &playerstrocarfrente_51_instances, &playerstrocartrs_52_instances, NULL};
    qualifier_9.set(4, &qualifier_9_instances[0]);
    static ObjectList* qualifier_2_instances[] = {&opesdificuldade_19_instances, &opesshaders_20_instances, &opesstreamermodehud_21_instances, &opesvoltar_22_instances, &opesbotodificuldade_23_instances, &opesbotostreamermode_24_instances, &opesbotoshaders_25_instances, &opesgrficos_73_instances, &opesrenderapi_74_instances, &opesbotogrficos_75_instances, &opesbotorenderapi_76_instances, NULL};
    qualifier_2.set(11, &qualifier_2_instances[0]);
    static ObjectList* qualifier_3_instances[] = {&escolhernoitehud_32_instances, &escolhernoitenoites_34_instances, &escolhernoitetrocarfrente_35_instances, &escolhernoitetrocartrs_36_instances, &escolhernoitevoltar_37_instances, &escolhernoitestart_39_instances, NULL};
    qualifier_3.set(6, &qualifier_3_instances[0]);
    static ObjectList* qualifier_0_instances[] = {&loadingfundo_63_instances, &loadingtexto_64_instances, NULL};
    qualifier_0.set(2, &qualifier_0_instances[0]);
    static ObjectList* qualifier_1_instances[] = {&menumultiplayer_9_instances, &menusingleplayer_10_instances, &menuoptions_11_instances, NULL};
    qualifier_1.set(3, &qualifier_1_instances[0]);
    static ObjectList* qualifier_6_instances[] = {&joinhud_57_instances, &joinvoltar_58_instances, &joinhudip_61_instances, &joinstart_62_instances, NULL};
    qualifier_6.set(4, &qualifier_6_instances[0]);
    static ObjectList* qualifier_7_instances[] = {&escolhernoitetrocarfrente_35_instances, &escolhernoitetrocartrs_36_instances, &escolhernoitevoltar_37_instances, &escolhernoitestart_39_instances, NULL};
    qualifier_7.set(4, &qualifier_7_instances[0]);
    static ObjectList* qualifier_4_instances[] = {&hojvoltar_42_instances, &hojhostgame_44_instances, &hojjoingame_45_instances, NULL};
    qualifier_4.set(3, &qualifier_4_instances[0]);
    static ObjectList* qualifier_5_instances[] = {&playershud_48_instances, &playersprximo_50_instances, &playerstrocarfrente_51_instances, &playerstrocartrs_52_instances, &playersvoltar_53_instances, &playersnumero_56_instances, NULL};
    qualifier_5.set(6, &qualifier_5_instances[0]);
    static ObjectList* qualifier_10_instances[] = {&playersprximo_50_instances, &playerstrocarfrente_51_instances, &playerstrocartrs_52_instances, &playersvoltar_53_instances, NULL};
    qualifier_10.set(4, &qualifier_10_instances[0]);
    static ObjectList* qualifier_11_instances[] = {&escolhernoitestart_39_instances, &playersprximo_50_instances, &joinstart_62_instances, NULL};
    qualifier_11.set(3, &qualifier_11_instances[0]);
    static ObjectList* qualifier_12_instances[] = {&joinvoltar_58_instances, &joinstart_62_instances, NULL};
    qualifier_12.set(2, &qualifier_12_instances[0]);
    static ObjectList* qualifier_13_instances[] = {&opesdificuldade_19_instances, &opesshaders_20_instances, &opesstreamermodehud_21_instances, &opesvoltar_22_instances, &opesgrficos_73_instances, &opesrenderapi_74_instances, NULL};
    qualifier_13.set(6, &qualifier_13_instances[0]);
    add_object(create_hudbackground_7(960, 540), 0);
    add_object(create_bancodedadoslauncher_17(15, -17), 0);
    add_object(create_bancodedadosinteraomenu_18(47, -17), 0);
    add_object(create_hudvinheta_31(960, 540), 0);
    add_object(create_menulogo_8(960, 540), 0);
    add_object(create_menucolisobotogamejolt_68(435, 280), 0);
    add_object(create_ini_70(-32, -64), 0);
    add_object(create_miscbotovolume_77(1808, 112), 1);
    add_object(create_miscbotodiscord_78(1680, 112), 1);
    add_object(create_miscbotoyt_79(1552, 112), 1);
    add_object(create_menumultiplayer_9(822, 803), 2);
    add_object(create_menusingleplayer_10(364, 640), 2);
    add_object(create_menuoptions_11(262, 832), 2);
    add_object(create_hudindicadorsingleplayer_13(98, 640), 2);
    add_object(create_hudindicadormultiplayer_14(98, 736), 2);
    add_object(create_hudindicadoroptions_15(98, 832), 2);
    add_object(create_opesdificuldade_19(128, 704), 3);
    add_object(create_opesshaders_20(128, 800), 3);
    add_object(create_opesstreamermodehud_21(128, 608), 3);
    add_object(create_opesvoltar_22(127, 952), 3);
    add_object(create_opesbotodificuldade_23(520, 736), 3);
    add_object(create_opesbotostreamermode_24(712, 640), 3);
    add_object(create_opesbotoshaders_25(680, 832), 3);
    add_object(create_opesindicadorvoltar_26(37, 952), 3);
    add_object(create_opesindicadorstreamermode_27(98, 640), 3);
    add_object(create_opesindicadordificuldade_28(98, 736), 3);
    add_object(create_opesindicadorshaders_29(98, 832), 3);
    add_object(create_opesindicadorgrficos_71(866, 640), 3);
    add_object(create_opesindicadorrenderapi_72(866, 736), 3);
    add_object(create_opesgrficos_73(896, 608), 3);
    add_object(create_opesrenderapi_74(896, 704), 3);
    add_object(create_opesbotogrficos_75(1247, 640), 3);
    add_object(create_opesbotorenderapi_76(1300, 736), 3);
    add_object(create_escolhernoitehud_32(464, 624), 4);
    add_object(create_escolheropespontocentral_33(464, 671), 4);
    add_object(create_escolhernoitenoites_34(845, 864), 4);
    add_object(create_escolhernoitenoites_34(845, 928), 4);
    add_object(create_escolhernoitenoites_34(845, 992), 4);
    add_object(create_escolhernoitenoites_34(845, 1056), 4);
    add_object(create_escolhernoitenoites_34(845, 1120), 4);
    add_object(create_escolhernoitenoites_34(845, 1184), 4);
    add_object(create_escolhernoitetrocarfrente_35(611, 888), 4);
    add_object(create_escolhernoitetrocartrs_36(317, 888), 4);
    add_object(create_escolhernoitevoltar_37(127, 952), 4);
    add_object(create_escolhernoiteindicadorvoltar_38(37, 952), 4);
    add_object(create_escolhernoitestart_39(464, 888), 4);
    add_object(create_escolhernoiteselecionaropo_40(455, 800), 4);
    add_object(create_escolhernoitevervarivel_41(462, 1061), 4);
    add_object(create_hojvoltar_42(127, 952), 5);
    add_object(create_hojindicadorvoltar_43(37, 952), 5);
    add_object(create_hojhostgame_44(313, 640), 5);
    add_object(create_hojjoingame_45(306, 736), 5);
    add_object(create_hojindicadorjoin_46(98, 736), 5);
    add_object(create_hojindicadorhost_47(98, 640), 5);
    add_object(create_playerstrocarfrente_51(611, 888), 6);
    add_object(create_playerstrocartrs_52(317, 888), 6);
    add_object(create_playersvoltar_53(127, 952), 6);
    add_object(create_playersindicadorvoltar_54(37, 952), 6);
    add_object(create_playersprximo_50(464, 888), 6);
    add_object(create_playersnumero_56(756, 672), 6);
    add_object(create_playersnumero_56(756, 736), 6);
    add_object(create_playersnumero_56(756, 800), 6);
    add_object(create_playersnumero_56(756, 864), 6);
    add_object(create_playersnumero_56(756, 928), 6);
    add_object(create_playersnumero_56(756, 992), 6);
    add_object(create_playersnumero_56(756, 1056), 6);
    add_object(create_playersselecionaropo_55(464, 816), 6);
    add_object(create_playershud_48(464, 592), 6);
    add_object(create_joinhud_57(317, 640), 7);
    add_object(create_joinvoltar_58(127, 952), 7);
    add_object(create_joinindicadorvoltar_59(37, 952), 7);
    add_object(create_joinhudip_61(124, 700), 7);
    add_object(create_joinstart_62(392, 855), 7);
    add_object(create_joinip_60(128, 704), 7);
    add_object(create_hudchiado_30(960, 540), 8);
    add_object(create_hudcrditos_12(960, 540), 8);
    add_object(create_hudcrditos_12(960, 540), 8);
    add_object(create_loadingfundo_63(960, 540), 9);
    add_object(create_loadingtexto_64(960, 540), 9);
    add_object(create_hudfadegame_49(960, 540), 9);
    loops = NULL;
    not_always_194_1 = loop_count;
    not_always_193_1 = loop_count;
    not_always_154_1 = loop_count;
    not_always_195_1 = loop_count;
    not_always_152_1 = loop_count;
    not_always_155_1 = loop_count;
    not_always_159_1 = loop_count;
    not_always_174_1 = loop_count;
    not_always_153_1 = loop_count;
    not_always_52_1 = loop_count;
    not_always_161_1 = loop_count;
    not_always_175_1 = loop_count;
    not_always_196_1 = loop_count;
    not_always_162_1 = loop_count;
    not_always_171_1 = loop_count;
    not_always_165_1 = loop_count;
    not_always_160_1 = loop_count;
    every_7_1 = 0.0f;
    not_always_163_1 = loop_count;
    not_always_157_1 = loop_count;
    not_always_156_1 = loop_count;
    not_always_151_1 = loop_count;
    not_always_158_1 = loop_count;
    not_always_166_1 = loop_count;
    not_always_164_1 = loop_count;
    not_always_8_1 = loop_count;
    not_always_170_1 = loop_count;
}
static void update_active_0(ObjectList ** lists, int count)
{
    ObjectList::iterator it;
    for (int i = 0; i < count; i++) {
        ObjectList & list = *lists[i];
        for (it = list.begin(); it != list.end(); ++it) {
            FrameObject * instance = it->obj;
            if (instance->flags & DESTROYING)
                continue;
            instance->update_inactive();
            if (instance->flags & INACTIVE)
                continue;
            ((Active*)instance)->update();
        }
    }
}
static void update_active_1(ObjectList ** lists, int count)
{
    ObjectList::iterator it;
    for (int i = 0; i < count; i++) {
        ObjectList & list = *lists[i];
        for (it = list.begin(); it != list.end(); ++it) {
            FrameObject * instance = it->obj;
            if (instance->flags & DESTROYING)
                continue;
            ((Active*)instance)->update();
        }
    }
}
static void update_active_2(ObjectList ** lists, int count)
{
    ObjectList::iterator it;
    for (int i = 0; i < count; i++) {
        ObjectList & list = *lists[i];
        for (it = list.begin(); it != list.end(); ++it) {
            FrameObject * instance = it->obj;
            if (instance->flags & DESTROYING)
                continue;
            instance->update_kill();
            if (instance->flags & INACTIVE)
                continue;
            ((Active*)instance)->update();
        }
    }
}
static void update_editobject_3(ObjectList ** lists, int count)
{
    ObjectList::iterator it;
    for (int i = 0; i < count; i++) {
        ObjectList & list = *lists[i];
        for (it = list.begin(); it != list.end(); ++it) {
            FrameObject * instance = it->obj;
            if (instance->flags & DESTROYING)
                continue;
            instance->update_inactive();
            if (instance->flags & INACTIVE)
                continue;
            ((EditObject*)instance)->update();
        }
    }
}
void Frames::update_objects()
{
    update_active_2(update_active_2_list, 1);
    update_editobject_3(update_editobject_3_list, 1);
    update_active_0(update_active_0_list, 39);
    update_active_1(update_active_1_list, 31);
}
Frames::Frames()
: Frame()
{
    update_active_2_list[0] = &hudcrditos_12_instances;
    update_editobject_3_list[0] = &joinip_60_instances;
    update_active_0_list[0] = &escolhernoitehud_32_instances;
    update_active_0_list[1] = &opesbotorenderapi_76_instances;
    update_active_0_list[2] = &vinheta_5_instances;
    update_active_0_list[3] = &hudbackground_7_instances;
    update_active_0_list[4] = &opesindicadorshaders_29_instances;
    update_active_0_list[5] = &escolheropespontocentral_33_instances;
    update_active_0_list[6] = &hudindicadormultiplayer_14_instances;
    update_active_0_list[7] = &hudvinheta_31_instances;
    update_active_0_list[8] = &bancodedadosinteraomenu_18_instances;
    update_active_0_list[9] = &warning_0_instances;
    update_active_0_list[10] = &joinhud_57_instances;
    update_active_0_list[11] = &escolhernoiteindicadorvoltar_38_instances;
    update_active_0_list[12] = &joinindicadorvoltar_59_instances;
    update_active_0_list[13] = &opesbotostreamermode_24_instances;
    update_active_0_list[14] = &playershud_48_instances;
    update_active_0_list[15] = &menucolisobotogamejolt_68_instances;
    update_active_0_list[16] = &opesindicadorrenderapi_72_instances;
    update_active_0_list[17] = &fade_1_instances;
    update_active_0_list[18] = &hudfadegame_49_instances;
    update_active_0_list[19] = &easteregg_3_instances;
    update_active_0_list[20] = &opesbotoshaders_25_instances;
    update_active_0_list[21] = &easteregg_6_instances;
    update_active_0_list[22] = &opesbotodificuldade_23_instances;
    update_active_0_list[23] = &opesindicadorstreamermode_27_instances;
    update_active_0_list[24] = &hojindicadorhost_47_instances;
    update_active_0_list[25] = &playersindicadorvoltar_54_instances;
    update_active_0_list[26] = &opesindicadorgrficos_71_instances;
    update_active_0_list[27] = &opesbotogrficos_75_instances;
    update_active_0_list[28] = &loadingtexto_64_instances;
    update_active_0_list[29] = &hudindicadorsingleplayer_13_instances;
    update_active_0_list[30] = &bancodedadoslauncher_17_instances;
    update_active_0_list[31] = &hudindicadoroptions_15_instances;
    update_active_0_list[32] = &fundowarning_4_instances;
    update_active_0_list[33] = &joinhudip_61_instances;
    update_active_0_list[34] = &opesindicadorvoltar_26_instances;
    update_active_0_list[35] = &hojindicadorvoltar_43_instances;
    update_active_0_list[36] = &menulogo_8_instances;
    update_active_0_list[37] = &hojindicadorjoin_46_instances;
    update_active_0_list[38] = &opesindicadordificuldade_28_instances;
    update_active_1_list[0] = &playerstrocartrs_52_instances;
    update_active_1_list[1] = &playersnumero_56_instances;
    update_active_1_list[2] = &menumultiplayer_9_instances;
    update_active_1_list[3] = &menuoptions_11_instances;
    update_active_1_list[4] = &playersvoltar_53_instances;
    update_active_1_list[5] = &escolhernoitetrocarfrente_35_instances;
    update_active_1_list[6] = &playersselecionaropo_55_instances;
    update_active_1_list[7] = &opesshaders_20_instances;
    update_active_1_list[8] = &miscbotovolume_77_instances;
    update_active_1_list[9] = &hojvoltar_42_instances;
    update_active_1_list[10] = &joinstart_62_instances;
    update_active_1_list[11] = &miscbotoyt_79_instances;
    update_active_1_list[12] = &hojhostgame_44_instances;
    update_active_1_list[13] = &opesstreamermodehud_21_instances;
    update_active_1_list[14] = &hojjoingame_45_instances;
    update_active_1_list[15] = &menusingleplayer_10_instances;
    update_active_1_list[16] = &hudchiado_30_instances;
    update_active_1_list[17] = &escolhernoitenoites_34_instances;
    update_active_1_list[18] = &playerstrocarfrente_51_instances;
    update_active_1_list[19] = &escolhernoitetrocartrs_36_instances;
    update_active_1_list[20] = &joinvoltar_58_instances;
    update_active_1_list[21] = &escolhernoiteselecionaropo_40_instances;
    update_active_1_list[22] = &miscbotodiscord_78_instances;
    update_active_1_list[23] = &opesgrficos_73_instances;
    update_active_1_list[24] = &escolhernoitevoltar_37_instances;
    update_active_1_list[25] = &opesdificuldade_19_instances;
    update_active_1_list[26] = &opesvoltar_22_instances;
    update_active_1_list[27] = &escolhernoitestart_39_instances;
    update_active_1_list[28] = &opesrenderapi_74_instances;
    update_active_1_list[29] = &loadingfundo_63_instances;
    update_active_1_list[30] = &playersprximo_50_instances;
}
void Frames::set_index(int index)
{
    static Frame1 frame1;
    static Frame2 frame2;
    switch (index) {
        case 0:
            data = &frame1;
            break;
        case 1:
            data = &frame2;
            break;
        default:
            data = NULL;
            break;
    }
    data->frame = this;
}

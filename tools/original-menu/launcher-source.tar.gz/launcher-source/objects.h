#ifndef CHOWDREN_OBJECTS_H
#define CHOWDREN_OBJECTS_H

#include "common.h"

#define Warning_0_type 2
FrameObject * create_warning_0(int x, int y);
#define Fade_1_type 3
FrameObject * create_fade_1(int x, int y);
#define EasterEgg_3_type 4
FrameObject * create_easteregg_3(int x, int y);
#define FundoWarning_4_type 5
FrameObject * create_fundowarning_4(int x, int y);
#define Vinheta_5_type 6
FrameObject * create_vinheta_5(int x, int y);
#define EASTEREGG_6_type 7
FrameObject * create_easteregg_6(int x, int y);
#define HUDBackground_7_type 8
FrameObject * create_hudbackground_7(int x, int y);
#define MENULogo_8_type 9
FrameObject * create_menulogo_8(int x, int y);
#define MENUMultiplayer_9_type 10
FrameObject * create_menumultiplayer_9(int x, int y);
#define MENUSingleplayer_10_type 11
FrameObject * create_menusingleplayer_10(int x, int y);
#define MENUOptions_11_type 12
FrameObject * create_menuoptions_11(int x, int y);
#define HUDCrDitos_12_type 13
FrameObject * create_hudcrditos_12(int x, int y);
#define HUDIndicadorSingleplayer_13_type 14
FrameObject * create_hudindicadorsingleplayer_13(int x, int y);
#define HUDIndicadorMultiplayer_14_type 15
FrameObject * create_hudindicadormultiplayer_14(int x, int y);
#define HUDIndicadorOptions_15_type 16
FrameObject * create_hudindicadoroptions_15(int x, int y);
#define BANCODEDADOSLauncher_17_type 17
FrameObject * create_bancodedadoslauncher_17(int x, int y);
#define BANCODEDADOSInteraOMenu_18_type 18
FrameObject * create_bancodedadosinteraomenu_18(int x, int y);
#define OPESDificuldade_19_type 19
FrameObject * create_opesdificuldade_19(int x, int y);
#define OPESShaders_20_type 20
FrameObject * create_opesshaders_20(int x, int y);
#define OPESStreamerModeHUD_21_type 21
FrameObject * create_opesstreamermodehud_21(int x, int y);
#define OPESVoltar_22_type 22
FrameObject * create_opesvoltar_22(int x, int y);
#define OPESBotODificuldade_23_type 23
FrameObject * create_opesbotodificuldade_23(int x, int y);
#define OPESBotOStreamerMode_24_type 24
FrameObject * create_opesbotostreamermode_24(int x, int y);
#define OPESBotOShaders_25_type 25
FrameObject * create_opesbotoshaders_25(int x, int y);
#define OPESIndicadorVoltar_26_type 26
FrameObject * create_opesindicadorvoltar_26(int x, int y);
#define OPESIndicadorStreamerMode_27_type 27
FrameObject * create_opesindicadorstreamermode_27(int x, int y);
#define OPESIndicadorDificuldade_28_type 28
FrameObject * create_opesindicadordificuldade_28(int x, int y);
#define OPESIndicadorShaders_29_type 29
FrameObject * create_opesindicadorshaders_29(int x, int y);
#define HUDChiado_30_type 30
FrameObject * create_hudchiado_30(int x, int y);
#define HUDVinheta_31_type 31
FrameObject * create_hudvinheta_31(int x, int y);
#define ESCOLHERNOITEHud_32_type 32
FrameObject * create_escolhernoitehud_32(int x, int y);
#define ESCOLHEROPESPontoCentral_33_type 33
FrameObject * create_escolheropespontocentral_33(int x, int y);
#define ESCOLHERNOITENoites_34_type 34
FrameObject * create_escolhernoitenoites_34(int x, int y);
#define ESCOLHERNOITETrocarFrente_35_type 35
FrameObject * create_escolhernoitetrocarfrente_35(int x, int y);
#define ESCOLHERNOITETrocarTrS_36_type 36
FrameObject * create_escolhernoitetrocartrs_36(int x, int y);
#define ESCOLHERNOITEVoltar_37_type 37
FrameObject * create_escolhernoitevoltar_37(int x, int y);
#define ESCOLHERNOITEIndicadorVoltar_38_type 38
FrameObject * create_escolhernoiteindicadorvoltar_38(int x, int y);
#define ESCOLHERNOITEStart_39_type 39
FrameObject * create_escolhernoitestart_39(int x, int y);
#define ESCOLHERNOITESelecionarOpO_40_type 40
FrameObject * create_escolhernoiteselecionaropo_40(int x, int y);
#define ESCOLHERNOITEVerVariVel_41_type 41
FrameObject * create_escolhernoitevervarivel_41(int x, int y);
#define HoJVoltar_42_type 42
FrameObject * create_hojvoltar_42(int x, int y);
#define HoJIndicadorVoltar_43_type 43
FrameObject * create_hojindicadorvoltar_43(int x, int y);
#define HoJHostGame_44_type 44
FrameObject * create_hojhostgame_44(int x, int y);
#define HoJJoinGame_45_type 45
FrameObject * create_hojjoingame_45(int x, int y);
#define HoJIndicadorJoin_46_type 46
FrameObject * create_hojindicadorjoin_46(int x, int y);
#define HoJIndicadorHost_47_type 47
FrameObject * create_hojindicadorhost_47(int x, int y);
#define PLAYERSHud_48_type 48
FrameObject * create_playershud_48(int x, int y);
#define HUDFadeGame_49_type 49
FrameObject * create_hudfadegame_49(int x, int y);
#define PLAYERSPrXimo_50_type 50
FrameObject * create_playersprximo_50(int x, int y);
#define PLAYERSTrocarFrente_51_type 51
FrameObject * create_playerstrocarfrente_51(int x, int y);
#define PLAYERSTrocarTrS_52_type 52
FrameObject * create_playerstrocartrs_52(int x, int y);
#define PLAYERSVoltar_53_type 53
FrameObject * create_playersvoltar_53(int x, int y);
#define PLAYERSIndicadorVoltar_54_type 54
FrameObject * create_playersindicadorvoltar_54(int x, int y);
#define PLAYERSSelecionarOpO_55_type 55
FrameObject * create_playersselecionaropo_55(int x, int y);
#define PLAYERSNumero_56_type 56
FrameObject * create_playersnumero_56(int x, int y);
#define JOINHud_57_type 57
FrameObject * create_joinhud_57(int x, int y);
#define JOINVoltar_58_type 58
FrameObject * create_joinvoltar_58(int x, int y);
#define JOINIndicadorVoltar_59_type 59
FrameObject * create_joinindicadorvoltar_59(int x, int y);
#define JOINIP_60_type 60
FrameObject * create_joinip_60(int x, int y);
#define JOINHudIP_61_type 61
FrameObject * create_joinhudip_61(int x, int y);
#define JOINStart_62_type 62
FrameObject * create_joinstart_62(int x, int y);
#define LOADINGFundo_63_type 63
FrameObject * create_loadingfundo_63(int x, int y);
#define LOADINGTexto_64_type 64
FrameObject * create_loadingtexto_64(int x, int y);
#define MENUColisOBotOGamejolt_68_type 65
FrameObject * create_menucolisobotogamejolt_68(int x, int y);
#define Ini_70_type 66
FrameObject * create_ini_70(int x, int y);
#define OPESIndicadorGrFicos_71_type 67
FrameObject * create_opesindicadorgrficos_71(int x, int y);
#define OPESIndicadorRenderAPI_72_type 68
FrameObject * create_opesindicadorrenderapi_72(int x, int y);
#define OPESGrFicos_73_type 69
FrameObject * create_opesgrficos_73(int x, int y);
#define OPESRenderAPI_74_type 70
FrameObject * create_opesrenderapi_74(int x, int y);
#define OPESBotOGrFicos_75_type 71
FrameObject * create_opesbotogrficos_75(int x, int y);
#define OPESBotORenderAPI_76_type 72
FrameObject * create_opesbotorenderapi_76(int x, int y);
#define MISCBotOVolume_77_type 73
FrameObject * create_miscbotovolume_77(int x, int y);
#define MISCBotODiscord_78_type 74
FrameObject * create_miscbotodiscord_78(int x, int y);
#define MISCBotOYT_79_type 75
FrameObject * create_miscbotoyt_79(int x, int y);

#endif // CHOWDREN_OBJECTS_H
